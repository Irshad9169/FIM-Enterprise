import logging
import httpx
import re
from datetime import datetime
from app.core.sso_manager import SSOManager
from sqlalchemy import text

logger = logging.getLogger("ticket_linker")
sso = SSOManager()

class TicketLinkerService:
    @staticmethod
    async def find_daily_review_ticket(report_date, token):
        """Finds the auto-generated RT ticket for the day"""
        # Format: Daily FIM Log Security Review - 2026/02/02
        date_str = report_date.strftime("%Y/%m/%d")
        subject_pattern = f"Daily FIM Log Security Review - {date_str}"
        rt_api_url = "http://rtapi.int.untd.com/cgi-bin/rt.cgi"
        
        try:
            async with httpx.AsyncClient(verify=False) as client:
                params = {'query': f"Subject = '{subject_pattern}'", 'sso_token': token}
                resp = await client.get(rt_api_url, params=params, timeout=5.0)
                if resp.status_code == 200 and ':' in resp.text:
                    # Return only the ID part of "12345: Subject"
                    return resp.text.split(':', 1)[0].strip()
        except Exception as e:
            logger.error(f"Failed to find daily RT ticket: {e}")
        return None

    @staticmethod
    async def post_review_to_rt(ticket_id, content, token):
        """Posts finalized forensics to RT as a comment"""
        rt_url = f"http://rtapi.int.untd.com/cgi-bin/rt.cgi/ticket/{ticket_id}/comment"
        try:
            async with httpx.AsyncClient(verify=False) as client:
                data = {"content": content, "sso_token": token}
                await client.post(rt_url, data=data, timeout=10.0)
                return True
        except Exception as e:
            logger.error(f"Failed to post to RT: {e}")
            return False

    @staticmethod
    async def correlate_report(report_id, agent_list, username, db):
        token = sso.create_outbound_token(username)
        async with httpx.AsyncClient(verify=False) as client:
            for hostname in agent_list:
                try:
                    # Logic to find CMRs for this host
                    cmr_url = "https://phantom.int.untd.com/bin/phantom"
                    params = {'action': 'display', 'type': 'runadvancedsearch', 'hostname': hostname, 'sso_token': token}
                    resp = await client.get(cmr_url, params=params, timeout=10.0)
                    if resp.status_code == 200:
                        cmr_ids = set(re.findall(r'#(\d{6})', resp.text))
                        for cid in cmr_ids:
                            await TicketLinkerService._save_link(db, report_id, hostname, 'cmr', cid, f"CMR for {hostname}", f"{cmr_url}?id={cid}")
                except: pass

    @staticmethod
    async def _save_link(db, report_id, hostname, source, ext_id, summary, url):
        query = text("""
            INSERT INTO fim.report_tickets (id, report_id, agent_hostname, source, external_id, summary, url, linked_at)
            VALUES (gen_random_uuid(), :rid, :h, :s, :eid, :sum, :url, NOW())
            ON CONFLICT DO NOTHING
        """)
        await db.execute(query, {"rid": report_id, "h": hostname, "s": source, "eid": ext_id, "sum": summary, "url": url})
