"""
Database Connection Management - Restored for Compatibility
"""
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)
Base = declarative_base()

class DatabaseManager:
    def __init__(self):
        self.engine = None
        self.async_session = None

    async def initialize(self):
        """Called by main.py lifespan"""
        if not self.engine:
            self.engine = create_async_engine(
                settings.database_url,
                pool_size=50,
                max_overflow=100,
                pool_timeout=30,
                pool_recycle=3600,
                pool_pre_ping=True
            )
            self.async_session = async_sessionmaker(
                self.engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autocommit=False,
                autoflush=False
            )
            logger.info("Database connection initialized")

    async def close(self):
        if self.engine:
            await self.engine.dispose()
            logger.info("Database connection closed")

db_manager = DatabaseManager()

async def get_db():
    """Stable Dependency using async with context manager"""
    async with db_manager.async_session() as session:
        try:
            yield session
        except Exception as e:
            logger.error(f"Database session error: {e}")
            await session.rollback()
            raise
