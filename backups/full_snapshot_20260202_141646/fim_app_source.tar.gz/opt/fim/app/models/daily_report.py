import uuid
from sqlalchemy import Column, String, Date, DateTime, Integer, Text, ForeignKey, Boolean, func, BigInteger
from sqlalchemy.dialects.postgresql import UUID, ARRAY, JSONB
from sqlalchemy.orm import relationship
from app.core.database import Base

class DailyReport(Base):
    __tablename__ = "reports"
    __table_args__ = {'schema': 'fim', 'extend_existing': True}
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    report_type = Column(String(20), default='daily')
    report_date = Column(Date, nullable=False, index=True)
    date_from = Column(Date)
    date_to = Column(Date)
    
    # Aggregated counts
    total_changes = Column(Integer, default=0)
    total_servers = Column(Integer, default=0)
    total_added = Column(Integer, default=0)
    total_removed = Column(Integer, default=0)
    total_changed = Column(Integer, default=0)
    
    known_changes = Column(Integer, default=0)
    unknown_changes = Column(Integer, default=0)
    correlation_groups_count = Column(Integer, default=0)
    
    # Agent list
    agent_list = Column(ARRAY(String))
    
    # Status and workflow
    status = Column(String(20), default='pending')
    
    # User references
    generated_by = Column(UUID(as_uuid=True), ForeignKey('fim.users.id'))
    reviewed_by = Column(UUID(as_uuid=True), ForeignKey('fim.users.id'))
    submitted_by = Column(UUID(as_uuid=True), ForeignKey('fim.users.id'))
    
    # RT ticket integration
    rt_ticket_searched = Column(Boolean, default=False)
    rt_ticket_found = Column(Boolean, default=False)
    rt_ticket_id = Column(String(50))
    rt_ticket_url = Column(Text)
    rt_search_error = Column(Text)
    
    # Notes
    analyst_notes = Column(Text)
    
    # Timestamps
    submitted_at = Column(DateTime)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    # Relationships
    changes = relationship("ReportChange", back_populates="report", cascade="all, delete-orphan")


class ReportChange(Base):
    __tablename__ = "report_changes"
    __table_args__ = {'schema': 'fim', 'extend_existing': True}
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    report_id = Column(UUID(as_uuid=True), ForeignKey('fim.reports.id', ondelete='CASCADE'), nullable=False)
    
    # Removed foreign key constraint to correlation_groups - just store UUID
    correlation_group_id = Column(UUID(as_uuid=True))
    alert_id = Column(UUID(as_uuid=True), ForeignKey('fim.alerts.id'))
    
    # File information
    agent_hostname = Column(String(255))
    file_path = Column(Text, nullable=False)
    change_type = Column(String(50), nullable=False)
    severity = Column(String(20))
    
    # Baseline vs Current comparison
    baseline_mtime = Column(DateTime)
    current_mtime = Column(DateTime)
    baseline_hash = Column(String(64))
    current_hash = Column(String(64))
    
    # NEW COLUMNS
    baseline_size = Column(BigInteger)
    current_size = Column(BigInteger)
    
    # RT ticket data - CORRECTED TO JSONB
    matched_rt_tickets = Column(JSONB)
    linked_rt_tickets = Column(ARRAY(String))
    rt_ticket_manually_added = Column(Boolean, default=False)
    
    # Analysis
    analyst_notes = Column(Text)
    is_known_change = Column(Boolean, default=False)
    evidence_provided = Column(Boolean, default=False)
    requires_investigation = Column(Boolean, default=True)
    
    # Review tracking
    reviewed_at = Column(DateTime)
    reviewed_by = Column(UUID(as_uuid=True), ForeignKey('fim.users.id'))
    
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    report = relationship("DailyReport", back_populates="changes")
