from fastapi import APIRouter, Depends, HTTPException, Response, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, text, or_
from datetime import date, datetime, timedelta, time
from typing import Optional, List, Dict, Any
import uuid
import json
import logging

from app.core.database import get_db
from app.models.daily_report import DailyReport, ReportChange
from app.schemas.daily_report import (
    DailyReportResponse, DailyReportDetail, GenerateReportRequest, 
    UpdateNotesRequest, UpdateStatusRequest, DailyReportSummary
)
from app.core.security import get_current_user
from app.models.models import User
from app.services.ticket_linker import TicketLinkerService

logger = logging.getLogger("report_api")
router = APIRouter()

def clean_host(host):
    return str(host or 'unknown').split('.')[0].lower().strip()

async def find_report(db, identifier):
    try:
        uid = uuid.UUID(identifier)
        res = await db.execute(select(DailyReport).where(DailyReport.id == uid))
        return res.scalar_one_or_none()
    except: pass
    res = await db.execute(select(DailyReport).where(func.cast(DailyReport.report_date, text('text')) == identifier))
    return res.scalar_one_or_none()

@router.get("", response_model=List[DailyReportResponse])
async def list_reports(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(DailyReport).order_by(DailyReport.report_date.desc()))
    return [DailyReportResponse(
        id=r.id, report_date=r.report_date, agents=r.agent_list or [],
        summary=DailyReportSummary(added_files=r.total_added, removed_files=r.total_removed, changed_files=r.total_changed),
        status=r.status, total_changes=r.total_changes, created_at=r.created_at
    ) for r in result.scalars().all()]

@router.get("/{id_or_date}")
async def get_report_grouped(id_or_date: str, db: AsyncSession = Depends(get_db)):
    r = await find_report(db, id_or_date)
    if not r: raise HTTPException(404, "Report not found")
    
    res_c = await db.execute(select(ReportChange).where(ReportChange.report_id == r.id))
    all_changes = res_c.scalars().all()
    
    res_t = await db.execute(text("SELECT id, source, external_id, summary, url, agent_hostname, is_linked FROM fim.report_tickets WHERE report_id = :rid"), {"rid": r.id})
    all_tickets = [dict(row._mapping) for row in res_t.fetchall()]

    agent_to_group = {}
    for t in all_tickets:
        if t['is_linked']:
            agent_to_group[clean_host(t['agent_hostname'])] = f"{t['source'].upper()}-{t['external_id']}"

    groups = {}
    # Use data-driven agent list
    found_agents = sorted(list(set([str(c.agent_hostname).strip() for c in all_changes])))
    if not found_agents and r.agent_list: found_agents = r.agent_list

    for agent in found_agents:
        group_key = agent_to_group.get(clean_host(agent), "UNIQUE")
        if group_key not in groups:
            groups[group_key] = {"id": group_key, "agents": [], "tickets": [], "details": [], "notes": "", "is_locked": False}
        
        if agent not in groups[group_key]["agents"]:
            groups[group_key]["agents"].append(agent)
        
        for t in all_tickets:
            if clean_host(t['agent_hostname']) == clean_host(agent):
                t_obj = dict(t); t_obj['id'] = str(t_obj['id'])
                if t_obj not in groups[group_key]["tickets"]: groups[group_key]["tickets"].append(t_obj)
        
        for ac in all_changes:
            if clean_host(ac.agent_hostname) == clean_host(agent):
                groups[group_key]["details"].append({
                    "agent": agent, "file_path": ac.file_path, "change_type": ac.change_type,
                    "baseline_hash": ac.baseline_hash, "current_hash": ac.current_hash,
                    "baseline_size": ac.baseline_size, "current_size": ac.current_size,
                    "baseline_mtime": ac.baseline_mtime.isoformat() if ac.baseline_mtime else None,
                    "current_mtime": ac.current_mtime.isoformat() if ac.current_mtime else None
                })
                if ac.analyst_notes:
                    groups[group_key]["notes"] = ac.analyst_notes
                    groups[group_key]["is_locked"] = True

    return {
        "id": str(r.id), "report_date": str(r.report_date), "status": r.status, 
        "total_changes": r.total_changes, "summary": {"added": r.total_added, "removed": r.total_removed, "changed": r.total_changed}, 
        "groups": list(groups.values())
    }

@router.post("/generate")
async def generate_daily_report(request: GenerateReportRequest, db: AsyncSession = Depends(get_db), u: User = Depends(get_current_user)):
    try:
        report_date = request.report_date or datetime.now().date()
        res = await db.execute(select(DailyReport).where(DailyReport.report_date == report_date))
        if res.scalar_one_or_none(): raise HTTPException(400, "Exists")
        q = text("SELECT a.id, a.file_path, a.alert_type, a.severity, a.previous_state, a.current_state, a.detected_at, ag.hostname FROM fim.alerts a LEFT JOIN fim.agents ag ON a.agent_id = ag.id WHERE DATE(a.created_at) = :d")
        res = await db.execute(q, {"d": report_date})
        all_alerts = res.fetchall()
        report_id = uuid.uuid4(); agents = list(set([a.hostname for a in all_alerts if a.hostname]))
        report = DailyReport(id=report_id, report_date=report_date, agent_list=agents, total_added=0, total_removed=0, total_changed=len(all_alerts), total_changes=len(all_alerts), total_servers=len(agents), status='pending')
        db.add(report); await db.flush()
        for a in all_alerts:
            p = json.loads(a.previous_state) if isinstance(a.previous_state, str) else (a.previous_state or {})
            c = json.loads(a.current_state) if isinstance(a.current_state, str) else (a.current_state or {})
            db.add(ReportChange(id=uuid.uuid4(), report_id=report_id, alert_id=a.id, agent_hostname=a.hostname or 'unknown', file_path=a.file_path or 'unknown', change_type='changed', severity=a.severity or 'medium', current_mtime=a.detected_at, baseline_hash=p.get('hash'), current_hash=c.get('hash'), baseline_size=p.get('size'), current_size=c.get('size')))
        await TicketLinkerService.correlate_report(report_id, agents, u.username, db)
        await db.commit()
        return {"message": "Success", "report_id": str(report_id)}
    except Exception as e:
        await db.rollback(); raise HTTPException(500, str(e))

@router.delete("/{report_id}")
async def delete_report(report_id: str, db: AsyncSession = Depends(get_db)):
    res = await db.execute(text("SELECT id FROM fim.reports WHERE id::text = :id OR report_date::text = :id"), {"id": report_id})
    row = res.fetchone()
    if not row: raise HTTPException(404)
    rid = row[0]
    await db.execute(text("DELETE FROM fim.report_changes WHERE report_id = :id"), {"id": rid})
    await db.execute(text("DELETE FROM fim.report_tickets WHERE report_id = :id"), {"id": rid})
    await db.execute(text("DELETE FROM fim.reports WHERE id = :id"), {"id": rid})
    await db.commit()
    return {"message": "Deleted"}

@router.get("/{id_or_date}/export")
async def export_report(id_or_date: str, db: AsyncSession = Depends(get_db)):
    r = await find_report(db, id_or_date)
    if not r: raise HTTPException(404)
    res_c = await db.execute(select(ReportChange).where(ReportChange.report_id == r.id))
    changes = res_c.scalars().all()
    lines = [f"FIM Report: {r.report_date}", "="*20]
    for c in changes:
        lines.append(f"[{c.agent_hostname}] {c.change_type.upper()}: {c.file_path}\n  Hash: {c.baseline_hash} -> {c.current_hash}")
    return Response("\n".join(lines), media_type="text/plain")

@router.patch("/{report_id}/group-notes")
async def update_group_notes(report_id: str, agents: List[str] = Body(...), notes: str = Body(...), db: AsyncSession = Depends(get_db)):
    r = await find_report(db, report_id)
    if not r: raise HTTPException(404)
    # Use fuzzy match for update too
    for agent in agents:
        query = text("UPDATE fim.report_changes SET analyst_notes = :n WHERE report_id = :rid AND agent_hostname LIKE :ah")
        await db.execute(query, {"n": notes, "rid": r.id, "ah": f"{agent.split('.')[0]}%"})
    await db.commit()
    return {"message": "updated"}

@router.patch("/{report_id}/status")
async def update_status(report_id: str, req: UpdateStatusRequest, db: AsyncSession = Depends(get_db)):
    r = await find_report(db, report_id)
    if not r: raise HTTPException(404)
    r.status = req.status
    await db.commit()
    return {"message": "updated"}

@router.post("/link-ticket/{ticket_id}")
async def toggle_ticket_link(ticket_id: str, db: AsyncSession = Depends(get_db)):
    res = await db.execute(text("UPDATE fim.report_tickets SET is_linked = NOT is_linked WHERE id::text = :tid RETURNING is_linked"), {"tid": ticket_id})
    row = res.fetchone()
    await db.commit()
    return {"is_linked": row[0] if row else False}
