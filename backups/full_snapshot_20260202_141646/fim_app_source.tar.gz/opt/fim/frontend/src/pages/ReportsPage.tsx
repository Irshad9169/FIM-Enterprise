import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { fetchReports, generateReport, deleteReport } from "../api/dashboard";
import { Eye, FileText, Download, Trash2, RefreshCw, Plus, Calendar, User, Wifi, Link as LinkIcon } from "lucide-react";
import { format, parseISO } from "date-fns";

export default function ReportsPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [selectedDate, setSelectedDate] = useState("");
  
  const { data: reports, isLoading, refetch } = useQuery({ queryKey: ["reports"], queryFn: () => fetchReports(50) });

  const deleteMutation = useMutation({
    mutationFn: deleteReport,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["reports"] }),
  });

  const getReportName = (dateStr: string) => {
    try {
      const dateObj = parseISO(dateStr);
      return `FIM-report-${format(dateObj, "EEE")}-${format(dateObj, "ddMMyyyy")}.htm`;
    } catch { return `FIM-report-${dateStr}.htm`; }
  };

  if (isLoading) return <div className="text-center py-12 text-slate-400">Loading reports...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-slate-900 p-4 rounded-lg border border-slate-800">
        <h1 className="text-xl font-bold text-white">Daily Reports</h1>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-slate-300"><User size={16} /><span>admin</span></div>
          <div className="px-3 py-1 bg-green-900/30 text-green-400 border border-green-800 rounded-full text-xs font-medium flex items-center gap-2"><Wifi size={14} />Connected</div>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <h2 className="text-base font-semibold text-slate-200">Daily Scan Reports</h2>
          <div className="flex items-center bg-slate-950 p-1.5 rounded border border-slate-700">
            <input type="date" className="bg-slate-800 border border-slate-600 text-sm text-white rounded px-3 py-1 outline-none [&::-webkit-calendar-picker-indicator]:invert" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
            <button onClick={() => generateReport(selectedDate).then(() => refetch())} className="px-4 py-1.5 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 ml-2">Generate</button>
            <button onClick={() => generateReport(new Date().toISOString().split('T')[0]).then(() => refetch())} className="px-4 py-1.5 bg-slate-800 text-cyan-400 border border-slate-700 text-xs font-medium rounded hover:bg-slate-700 ml-2">Today</button>
          </div>
          <div className="flex gap-2">
            <button onClick={() => generateReport(new Date().toISOString().split('T')[0]).then(() => refetch())} className="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 flex items-center gap-2 shadow-sm"><Plus size={16} /> Generate Today's Report</button>
            <button onClick={() => refetch()} className="px-4 py-2 bg-blue-500 text-white text-sm font-medium rounded-lg hover:bg-blue-600 flex items-center gap-2 shadow-sm"><RefreshCw size={16} /> Refresh</button>
          </div>
        </div>

        <table className="w-full text-sm text-left text-slate-300">
          <thead className="bg-slate-950/50 text-slate-400 font-semibold uppercase text-xs border-b border-slate-800">
            <tr>
              <th className="px-6 py-4">Report Name</th>
              <th className="px-6 py-4">Date</th>
              <th className="px-6 py-4 text-center">Alerts</th>
              <th className="px-6 py-4 text-center">Status</th>
              <th className="px-6 py-4 text-center">Review Ticket</th>
              <th className="px-6 py-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {reports?.map((report: any) => (
              <tr key={report.id} className="hover:bg-slate-800/50 transition-colors">
                <td className="px-6 py-4 font-medium text-slate-200">{getReportName(report.report_date)}</td>
                <td className="px-6 py-4 font-mono text-slate-400">{report.report_date}</td>
                <td className="px-6 py-4 text-center"><span className={report.total_changes > 0 ? 'text-red-400 font-bold' : 'text-slate-500'}>{report.total_changes}</span></td>
                <td className="px-6 py-4 text-center"><span className="px-3 py-1 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 text-[10px] font-bold uppercase">{report.status}</span></td>
                <td className="px-6 py-4 text-center">
                    {report.rt_ticket_id ? (
                        <a href={`http://tickets.int.untd.com/Ticket/Display.html?id=${report.rt_ticket_id}`} target="_blank" className="flex items-center justify-center gap-1 text-blue-400 hover:underline">
                            <LinkIcon size={12}/> #{report.rt_ticket_id}
                        </a>
                    ) : '-'}
                </td>
                <td className="px-6 py-4 text-center">
                  <div className="flex justify-center gap-2">
                    <button onClick={() => navigate(`/reports/${report.id}`)} className="p-1.5 bg-blue-600 text-white rounded hover:bg-blue-700" title="View Details"><Eye size={16} /></button>
                    <button onClick={() => window.open(`/api/v1/reports/${report.id}/export?format=txt`, '_blank')} className="p-1.5 bg-slate-700 text-slate-300 border border-slate-600 rounded" title="View Text"><FileText size={16} /></button>
                    <button className="p-1.5 bg-slate-700 text-slate-300 border border-slate-600 rounded"><Download size={16} /></button>
                    <button onClick={() => confirm('Delete?') && deleteMutation.mutate(report.id)} className="p-1.5 bg-white text-red-500 border border-red-500 rounded hover:bg-red-500 hover:text-white"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
