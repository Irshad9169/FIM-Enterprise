import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchReportDetail, updateReportStatus } from "../api/dashboard";
import { 
  ArrowLeft, FileText, CheckCircle, ChevronDown, Save, 
  Link as LinkIcon, ExternalLink, Server, Layers, Lock 
} from "lucide-react";
import { useState, useEffect } from "react";

export default function ReportDetailPage() {
  const { reportId } = useParams<{ reportId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [groupNotes, setGroupNotes] = useState<Record<string, string>>({});

  // 1. Fetch Grouped Report Data
  const { data: report, isLoading, refetch } = useQuery({
    queryKey: ["report", reportId],
    queryFn: async () => {
        const token = localStorage.getItem("fim_token");
        const res = await fetch(`/api/v1/reports/${reportId}`, { 
          headers: { Authorization: `Bearer ${token}` } 
        });
        if (!res.ok) throw new Error("Load failed");
        return res.json();
    }
  });

  // 2. Synchronize local textarea state with database notes
  useEffect(() => {
    if (report?.groups) {
      const n: Record<string, string> = {};
      report.groups.forEach((g: any) => { n[g.id] = g.notes || ""; });
      setGroupNotes(n);
    }
  }, [report]);

  // 3. Action: Toggle Ticket Checkbox
  const handleToggleTicket = async (ticketId: string) => {
      const token = localStorage.getItem("fim_token");
      await fetch(`/api/v1/reports/link-ticket/${ticketId}`, { 
          method: 'POST', 
          headers: { Authorization: `Bearer ${token}` } 
      });
      refetch();
  };

  // 4. Action: Save and Lock Notes (Immutable)
  const handleSaveNotes = async (groupId: string, agents: string[]) => {
      if (!confirm("Caution: Once saved, these notes are locked for audit. Continue?")) return;
      
      const token = localStorage.getItem("fim_token");
      const res = await fetch(`/api/v1/reports/${reportId}/group-notes`, {
          method: 'PATCH',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ agents, notes: groupNotes[groupId] })
      });
      
      if (res.ok) { 
        alert("Justification Locked & Saved."); 
        refetch(); 
      } else { 
        alert("Error: This section might already be locked."); 
      }
  };

  if (isLoading) return <div className="p-12 text-center text-slate-400 font-mono">Loading Data & Correlating Tickets...</div>;
  if (!report) return <div className="p-12 text-center text-red-400">Report details not found.</div>;

  return (
    <div className="space-y-6">
      {/* Top Navigation Bar */}
      <div className="flex justify-between items-center print:hidden">
        <button onClick={() => navigate('/reports')} className="px-4 py-2 bg-slate-800 text-white rounded text-sm flex items-center gap-2 hover:bg-slate-700 transition-colors">
          <ArrowLeft size={16} /> Back to Reports
        </button>
        <div className="flex gap-2">
            <button onClick={() => window.open(`/api/v1/reports/${reportId}/export`, '_blank')} className="px-4 py-2 bg-slate-800 text-slate-200 border border-slate-700 rounded text-sm flex items-center gap-2 hover:bg-slate-700">
              <FileText size={16} /> View Text
            </button>
            <button onClick={() => updateReportStatus(reportId!, 'reviewed').then(() => refetch())} className="px-4 py-2 bg-green-600 text-white rounded text-sm flex items-center gap-2 hover:bg-green-700 font-bold">
              <CheckCircle size={16} /> Mark Reviewed
            </button>
        </div>
      </div>

      {/* Report Summary Header */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded shadow-sm">
        <h1 className="text-2xl font-bold text-white">FIM Report - {report.report_date}</h1>
        <div className="flex gap-6 mt-3 text-xs font-mono">
            <span className="text-slate-500 uppercase tracking-widest">Status: <span className="text-sky-400 font-bold">{report.status}</span></span>
            <span className="text-slate-500 uppercase tracking-widest">Alerts: <span className="text-white">{report.total_changes}</span></span>
        </div>
      </div>

      <h2 className="text-lg font-bold text-slate-300">Detailed Alerts by Cluster</h2>
      
      {/* Group/Cluster List */}
      {report.groups?.map((group: any) => (
        <div key={group.id} className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden mb-10 shadow-2xl">
          
          {/* Group Header (Agents) */}
          <div className="p-4 bg-slate-800/40 border-b border-slate-800 flex items-center gap-3">
              <div className="p-2 bg-blue-600/20 rounded-lg text-blue-400"><Layers size={20}/></div>
              <div>
                <div className="text-white font-bold">{group.id === "UNIQUE" ? "Standalone Changes" : `Ticket Group: ${group.id}`}</div>
                <div className="flex flex-wrap gap-2 mt-1">
                  {group.agents.map((a: string) => (
                    <span key={a} className="text-[10px] bg-slate-950 text-slate-300 px-2 py-0.5 rounded border border-slate-700 flex items-center gap-1">
                      <Server size={10} /> {a}
                    </span>
                  ))}
                </div>
              </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-0">
            
            {/* FORENSICS PANE (Left - 75%) */}
            <div className="lg:col-span-3 p-4 space-y-4 max-h-[700px] overflow-y-auto border-r border-slate-800 bg-slate-950/30">
              {group.details?.length > 0 ? group.details.map((d: any, idx: number) => (
                <div key={idx} className="border-l-4 border-yellow-600 p-4 bg-slate-900/50 rounded-r text-sm font-mono">
                    <div className="text-yellow-500 font-bold text-sm mb-2 uppercase tracking-tight">
                      modified — <span className="text-pink-400 normal-case">{d.file_path}</span>
                    </div>
                    <div className="grid grid-cols-1 gap-1.5 text-slate-400 text-[10px] break-all">
                      <div className="flex gap-2">
                        <span className="text-blue-500 font-bold min-w-[50px]">HASH:</span>
                        <span>{d.baseline_hash || 'N/A'} <span className="text-slate-600">→</span> {d.current_hash || 'N/A'}</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-slate-300 font-bold min-w-[50px]">SIZE:</span>
                        <span>{d.baseline_size || 0} bytes <span className="text-slate-600">→</span> {d.current_size || 0} bytes</span>
                      </div>
                      <div className="flex gap-2">
                        <span className="text-sky-400 font-bold min-w-[50px]">TIME:</span>
                        <span>{d.baseline_mtime || 'N/A'} <span className="text-slate-600">→</span> {d.current_mtime || 'N/A'}</span>
                      </div>
                    </div>
                </div>
              )) : (
                <div className="p-12 text-center text-slate-600 italic">No detailed changes linked to this group.</div>
              )}
            </div>

            {/* CONTEXT PANE (Right - 25%) */}
            <div className="p-4 bg-slate-900 space-y-8 border-l border-slate-800">
              
              {/* TICKETS SECTION */}
              <div>
                <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3 flex items-center justify-between">
                  Correlated Tickets
                  <LinkIcon size={12} />
                </h4>
                {group.tickets?.map((t: any, tidx: number) => (
                  <div key={tidx} className={`p-2 border rounded mb-2 flex items-start gap-2 transition-colors ${t.is_linked ? 'bg-blue-600/20 border-blue-500' : 'bg-slate-950 border-slate-800'}`}>
                    <input 
                      type="checkbox" 
                      checked={t.is_linked} 
                      onChange={() => handleToggleTicket(t.id)} 
                      disabled={group.is_locked}
                      className="mt-1 accent-blue-500" 
                    />
                    <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center text-blue-400 font-bold text-[10px]">
                            <span>{t.external_id} ({t.source.toUpperCase()})</span>
                            <a href={t.url} target="_blank" rel="noreferrer" className="text-slate-500 hover:text-white transition-colors">
                              <ExternalLink size={10}/>
                            </a>
                        </div>
                        <div className="text-[9px] text-slate-400 truncate leading-tight mt-1">{t.summary}</div>
                    </div>
                  </div>
                ))}
                {group.tickets.length === 0 && <div className="text-slate-700 text-[10px] italic">No common tickets found.</div>}
              </div>

              {/* NOTES SECTION */}
              <div>
                <div className="flex justify-between items-center mb-3">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Analyst Justification</h4>
                    {group.is_locked && <Lock size={12} className="text-red-500" />}
                </div>
                
                <textarea 
                  disabled={group.is_locked}
                  className={`w-full border rounded p-3 text-xs outline-none h-48 transition-all ${
                    group.is_locked 
                    ? 'bg-slate-800/50 text-slate-100 border-slate-700 cursor-default shadow-inner' 
                    : 'bg-slate-950 border-slate-800 text-slate-200 focus:border-blue-600 shadow-xl'
                  }`}
                  placeholder={group.is_locked ? "" : "Explain these changes for the audit trail..."}
                  value={groupNotes[group.id] || ""}
                  onChange={e => setGroupNotes({...groupNotes, [group.id]: e.target.value})}
                ></textarea>
                
                {!group.is_locked && (
                  <button 
                    onClick={() => handleSaveNotes(group.id, group.agents)} 
                    className="w-full mt-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded flex items-center justify-center gap-2 transition-all active:scale-95"
                  >
                    <Save size={14} /> Commit & Lock Notes
                  </button>
                )}
                {group.is_locked && (
                  <div className="mt-2 text-[9px] text-slate-500 italic text-center font-mono">
                    Locked for Audit - Signature Verified
                  </div>
                )}
              </div>
            </div>

          </div>
        </div>
      ))}
    </div>
  );
}
