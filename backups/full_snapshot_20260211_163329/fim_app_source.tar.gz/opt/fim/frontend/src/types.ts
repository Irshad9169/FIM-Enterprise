export type AlertSeverity = "critical" | "high" | "medium" | "low";
export type AlertStatus = "open" | "acknowledged" | "resolved";

export interface AlertStats {
  total_alerts: number;
  by_status: {
    open: number;
    acknowledged: number;
    resolved: number;
  };
  by_severity: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
}

export interface Agent {
  id: string;
  hostname: string;
  ip_address: string | null;
  os_type: string | null;
  os_version: string | null;
  agent_version: string | null;
  status: string;
  last_heartbeat: string | null;
  created_at: string | null;
}

export interface AgentsListResponse {
  agents: Agent[];
  total: number;
}

export interface HealthSummary {
  total_agents: number;
  online_agents: number;
  healthy_agents: number;
  unhealthy_agents: number;
  stale_agents: number;
}

export interface AlertsListItem {
  id: string;
  agent_id: string;
  agent_hostname: string;
  alert_type: string;
  severity: AlertSeverity;
  file_path: string;
  status: AlertStatus;
  change_details: Record<string, any> | null;
  previous_state: Record<string, any> | null;
  current_state: Record<string, any> | null;
  detected_at: string | null;
  created_at: string | null;
}
