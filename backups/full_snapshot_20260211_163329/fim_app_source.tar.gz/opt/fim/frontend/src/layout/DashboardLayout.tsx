import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { logout } from "../api/auth";
import { 
  LayoutDashboard, Server, Bell, FileCheck, Scan, FileText, Shield, 
  Users, History, LogOut, ShieldAlert
} from "lucide-react";

const navItemClass = ({ isActive }: { isActive: boolean }) =>
  `flex items-center gap-3 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
    isActive ? "bg-blue-600 text-white" : "text-slate-400 hover:bg-slate-800 hover:text-white"
  }`;

export default function DashboardLayout() {
  const navigate = useNavigate();
  const userRaw = localStorage.getItem("fim_user");
  const user = userRaw ? JSON.parse(userRaw) : null;

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-100 overflow-hidden">
      {/* Sidebar - Fixed width */}
      <aside className="w-64 border-r border-slate-800 flex flex-col shrink-0">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-2 font-bold text-xl text-white">
            <ShieldAlert className="text-blue-500" />
            FIM Enterprise
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-4">Main</div>
          <NavLink to="/" end className={navItemClass}>
            <LayoutDashboard size={18} /> Dashboard
          </NavLink>
          <NavLink to="/agents" className={navItemClass}>
            <Server size={18} /> Agents
          </NavLink>
          <NavLink to="/alerts" className={navItemClass}>
            <Bell size={18} /> Alerts
          </NavLink>

          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-6 mb-2 px-4">Operations</div>
          <NavLink to="/baselines" className={navItemClass}>
            <FileCheck size={18} /> Baselines
          </NavLink>
          <NavLink to="/scans" className={navItemClass}>
            <Scan size={18} /> Scans
          </NavLink>
          <NavLink to="/reports" className={navItemClass}>
            <FileText size={18} /> Daily Reports
          </NavLink>
          <NavLink to="/exclusions" className={navItemClass}>
            <Shield size={18} /> Exclusions
          </NavLink>

          {user?.role === 'admin' && (
            <>
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mt-6 mb-2 px-4">Administration</div>
              <NavLink to="/users" className={navItemClass}>
                <Users size={18} /> Users
              </NavLink>
              <NavLink to="/audit" className={navItemClass}>
                <History size={18} /> Audit Logs
              </NavLink>
            </>
          )}
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <div className="text-sm truncate mr-2">
              <div className="font-medium text-white truncate">{user?.username || 'User'}</div>
              <div className="text-xs text-slate-500 truncate">{user?.email}</div>
            </div>
            <button onClick={handleLogout} className="text-slate-400 hover:text-white p-1">
              <LogOut size={18} />
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area - Stretch to full width */}
      <main className="flex-1 overflow-auto bg-slate-950">
        <div className="w-full h-full p-8">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
