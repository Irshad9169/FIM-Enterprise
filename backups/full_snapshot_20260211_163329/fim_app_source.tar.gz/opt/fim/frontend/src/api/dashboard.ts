const API_BASE = "";

async function apiCall(endpoint: string, options?: RequestInit) {
  const token = localStorage.getItem("fim_token");
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });
  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}));
    throw new Error(errorBody.detail || `API call failed: ${response.statusText}`);
  }
  return response.json();
}

export const fetchDashboardStats = () => apiCall("/api/v1/dashboard/stats");
export const fetchRecentAlerts = (limit = 10) => apiCall(`/api/v1/dashboard/alerts/recent?limit=${limit}`);
export const fetchAgentHealth = () => apiCall("/api/v1/dashboard/agents/health");
export const fetchAlertStats = () => apiCall("/api/v1/dashboard/alerts/stats");
export const fetchHealthSummary = () => apiCall("/api/v1/dashboard/agents/health");
export const fetchAgents = () => apiCall("/api/v1/agents");
export const triggerScan = (agentId: string, force: boolean = false) => apiCall(`/api/v1/agents/${agentId}/scan?force=${force}`, { method: "POST" });
export const fetchAlerts = (params?: any) => {
  const query = params ? `?${new URLSearchParams(params)}` : '';
  return apiCall(`/api/v1/alerts${query}`);
};
export const fetchBaselines = () => apiCall("/api/v1/baselines");
export const deleteBaseline = (id: string) => apiCall(`/api/v1/baselines/${id}`, { method: "DELETE" });
export const fetchScans = () => apiCall("/api/v1/scans");

// REPORTS - UPDATED PATHS
export const fetchReports = (limit = 30) => apiCall(`/api/v1/reports?limit=${limit}`);
export const generateReport = (reportDate: string) => apiCall('/api/v1/reports/generate', { method: 'POST', body: JSON.stringify({ report_date: reportDate }) });

// Changed to /get/id/
export const fetchReportDetail = (reportId: string) => apiCall(`/api/v1/reports/get/id/${reportId}`);

export const deleteReport = (reportId: string) => apiCall(`/api/v1/reports/${reportId}`, { method: 'DELETE' });

// Changed to /export/id/
export const exportReport = async (reportId: string) => {
  const token = localStorage.getItem("fim_token");
  const response = await fetch(`/api/v1/reports/export/id/${reportId}?format=txt`, { headers: { Authorization: `Bearer ${token}` } });
  if (!response.ok) throw new Error("Failed to export report");
  return response.blob();
};

export const updateReportStatus = (reportId: string, status: string) => apiCall(`/api/v1/reports/${reportId}/status`, { method: 'PATCH', body: JSON.stringify({ status }) });

// Administration
export const fetchUsers = () => apiCall("/api/v1/users");
export const createUser = (data: any) => apiCall("/api/v1/users", { method: "POST", body: JSON.stringify(data) });
export const updateUser = (userId: string, data: any) => apiCall(`/api/v1/users/${userId}`, { method: "PATCH", body: JSON.stringify(data) });
export const deleteUser = (userId: string) => apiCall(`/api/v1/users/${userId}`, { method: "DELETE" });
export const fetchAuditLogs = () => apiCall("/api/v1/audit");
