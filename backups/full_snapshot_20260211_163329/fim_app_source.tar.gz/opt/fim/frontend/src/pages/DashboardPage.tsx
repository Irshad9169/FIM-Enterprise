import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { 
  fetchDashboardStats, fetchAlertStats, fetchHealthSummary 
} from "../api/dashboard";
import { 
  ShieldAlert, Activity, Server, FileText, CheckCircle, Clock 
} from "lucide-react";

// Helper for API call since it's not in main export list yet
const fetchReportStats = async () => {
  const token = localStorage.getItem("fim_token");
  const res = await fetch("/api/v1/dashboard/reports/stats", {
    headers: { Authorization: `Bearer ${token}` }
  });
  return res.json();
};

export default function DashboardPage() {
  const navigate = useNavigate();

  const { data: stats } = useQuery({
    queryKey: ["dashboardStats"],
    queryFn: fetchDashboardStats,
  });

  const { data: alertStats } = useQuery({
    queryKey: ["alertStats"],
    queryFn: fetchAlertStats,
  });

  const { data: health } = useQuery({
    queryKey: ["healthSummary"],
    queryFn: fetchHealthSummary,
  });

  const { data: reportStats } = useQuery({
    queryKey: ["reportStats"],
    queryFn: fetchReportStats,
  });

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          label="Total Alerts" 
          value={stats?.alerts.total || 0} 
          icon={<ShieldAlert className="text-red-500" size={24} />}
          onClick={() => navigate('/alerts')}
        />
        <StatCard 
          label="Open Alerts" 
          value={stats?.alerts.open || 0} 
          icon={<Activity className="text-orange-500" size={24} />}
          onClick={() => navigate('/alerts')}
        />
        <StatCard 
          label="Online Agents" 
          value={stats?.agents.online || 0} 
          icon={<Server className="text-green-500" size={24} />}
          onClick={() => navigate('/agents')}
        />
        
        {/* NEW REPORTS WIDGET */}
        <div 
          onClick={() => navigate('/reports')} 
          className="bg-slate-900 p-6 rounded-lg border border-slate-800 cursor-pointer hover:border-sky-600 transition-colors"
        >
          <div className="flex justify-between items-start">
            <div>
              <p className="text-slate-400 text-sm font-medium">Pending Reports</p>
              <h3 className="text-3xl font-bold text-white mt-2">{reportStats?.pending_review || 0}</h3>
            </div>
            <div className="p-2 bg-yellow-900/30 rounded-lg">
              <FileText className="text-yellow-500" size={24} />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-sm">
            <span className="text-red-400 font-medium">{reportStats?.missing_reports || 0}</span>
            <span className="text-slate-500">missing last 7 days</span>
          </div>
        </div>
      </div>

      {/* Alerts by Severity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800">
          <h3 className="text-lg font-semibold mb-4 text-white">Alerts by Severity</h3>
          <div className="grid grid-cols-2 gap-4">
            <SeverityCard label="Critical" value={alertStats?.by_severity.critical || 0} color="red" />
            <SeverityCard label="High" value={alertStats?.by_severity.high || 0} color="orange" />
            <SeverityCard label="Medium" value={alertStats?.by_severity.medium || 0} color="yellow" />
            <SeverityCard label="Low" value={alertStats?.by_severity.low || 0} color="blue" />
          </div>
        </div>

        <div className="bg-slate-900 p-6 rounded-lg border border-slate-800">
          <h3 className="text-lg font-semibold mb-4 text-white">Agent Health</h3>
          <div className="grid grid-cols-2 gap-4">
            <HealthCard label="Healthy" value={health?.healthy_agents || 0} icon={<CheckCircle size={20} />} color="text-green-500" />
            <HealthCard label="Unhealthy" value={health?.unhealthy_agents || 0} icon={<Activity size={20} />} color="text-red-500" />
            <HealthCard label="Stale" value={health?.stale_agents || 0} icon={<Clock size={20} />} color="text-slate-500" />
            <HealthCard label="Total" value={health?.total_agents || 0} icon={<Server size={20} />} color="text-blue-500" />
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, onClick }: any) {
  return (
    <div 
      onClick={onClick}
      className="bg-slate-900 p-6 rounded-lg border border-slate-800 cursor-pointer hover:border-sky-600 transition-colors"
    >
      <div className="flex justify-between items-start">
        <div>
          <p className="text-slate-400 text-sm font-medium">{label}</p>
          <h3 className="text-3xl font-bold text-white mt-2">{value}</h3>
        </div>
        <div className="p-2 bg-slate-800 rounded-lg">{icon}</div>
      </div>
    </div>
  );
}

function SeverityCard({ label, value, color }: any) {
  const colors: any = {
    red: "bg-red-900/20 text-red-500 border-red-900",
    orange: "bg-orange-900/20 text-orange-500 border-orange-900",
    yellow: "bg-yellow-900/20 text-yellow-500 border-yellow-900",
    blue: "bg-blue-900/20 text-blue-500 border-blue-900",
  };
  return (
    <div className={`p-4 rounded border ${colors[color]}`}>
      <div className="text-sm font-medium opacity-80">{label}</div>
      <div className="text-2xl font-bold mt-1">{value}</div>
    </div>
  );
}

function HealthCard({ label, value, icon, color }: any) {
  return (
    <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded border border-slate-700">
      <div className="flex items-center gap-3">
        <span className={color}>{icon}</span>
        <span className="text-slate-300 font-medium">{label}</span>
      </div>
      <span className="text-xl font-bold text-white">{value}</span>
    </div>
  );
}
