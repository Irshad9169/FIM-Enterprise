import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { fetchAlerts } from "../api/dashboard";
import AlertDetailsModal from "../components/AlertDetailsModal";

export default function AlertsPage() {
  const [selectedAlert, setSelectedAlert] = useState<any>(null);
  const [sortField, setSortField] = useState<string>("detected_at");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  const { data, isLoading, error } = useQuery({
    queryKey: ["alerts"],
    queryFn: () => fetchAlerts({ days: 30, limit: 1000 }),
    refetchInterval: 30_000,
  });

  if (isLoading) return <div className="text-center py-8">Loading alerts...</div>;
  if (error) return <div className="text-center py-8 text-red-400">Error loading alerts</div>;

  const alerts = data?.alerts || [];

  const sortedAlerts = [...alerts].sort((a: any, b: any) => {
    let aVal = a[sortField];
    let bVal = b[sortField];

    if (sortField === "detected_at") {
      aVal = aVal ? new Date(aVal).getTime() : 0;
      bVal = bVal ? new Date(bVal).getTime() : 0;
    }

    if (aVal === bVal) return 0;
    
    if (sortOrder === "asc") {
      return aVal > bVal ? 1 : -1;
    } else {
      return aVal < bVal ? 1 : -1;
    }
  });

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("desc");
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) return <span className="text-slate-600">⇅</span>;
    return <span className="text-sky-400">{sortOrder === "asc" ? "↑" : "↓"}</span>;
  };

  const exportToCSV = () => {
    const headers = ["Severity", "Status", "Agent", "File Path", "Detected At"];
    const rows = alerts.map((a: any) => [
      a.severity,
      a.status,
      a.agent_hostname,
      a.file_path,
      a.detected_at || "",
    ]);

    const csv = [
      headers.join(","),
      ...rows.map((row: any[]) => row.map((cell: any) => `"${cell}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fim-alerts-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold">
          Alerts <span className="text-slate-400 text-base">({alerts.length})</span>
        </h1>
        <button
          onClick={exportToCSV}
          disabled={alerts.length === 0}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 rounded text-sm border border-slate-600"
        >
          📥 Export CSV
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-800 text-slate-300">
            <tr>
              <th
                className="px-3 py-2 text-left cursor-pointer hover:bg-slate-700"
                onClick={() => handleSort("severity")}
              >
                Severity <SortIcon field="severity" />
              </th>
              <th
                className="px-3 py-2 text-left cursor-pointer hover:bg-slate-700"
                onClick={() => handleSort("status")}
              >
                Status <SortIcon field="status" />
              </th>
              <th
                className="px-3 py-2 text-left cursor-pointer hover:bg-slate-700"
                onClick={() => handleSort("agent_hostname")}
              >
                Agent <SortIcon field="agent_hostname" />
              </th>
              <th className="px-3 py-2 text-left">File</th>
              <th
                className="px-3 py-2 text-left cursor-pointer hover:bg-slate-700"
                onClick={() => handleSort("detected_at")}
              >
                Detected At <SortIcon field="detected_at" />
              </th>
              <th className="px-3 py-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedAlerts.map((a: any) => (
              <tr key={a.id} className="border-t border-slate-800 hover:bg-slate-800/50">
                <td className="px-3 py-2">
                  <span
                    className={`px-2 py-1 rounded-full text-xs border ${
                      a.severity === "critical"
                        ? "bg-red-900/40 text-red-300 border-red-700"
                        : a.severity === "high"
                        ? "bg-orange-900/40 text-orange-300 border-orange-700"
                        : "bg-slate-800 text-slate-200 border-slate-600"
                    }`}
                  >
                    {a.severity}
                  </span>
                </td>
                <td className="px-3 py-2 text-xs">{a.status}</td>
                <td className="px-3 py-2 text-xs text-slate-300">{a.agent_hostname}</td>
                <td className="px-3 py-2 text-xs text-slate-300 truncate max-w-xs">
                  {a.file_path}
                </td>
                <td className="px-3 py-2 text-xs text-slate-400">
                  {a.detected_at ? new Date(a.detected_at).toLocaleString() : "-"}
                </td>
                <td className="px-3 py-2 text-center">
                  <button
                    onClick={() => setSelectedAlert(a)}
                    className="text-sky-400 hover:text-sky-300 text-xs font-medium"
                  >
                    View Details
                  </button>
                </td>
              </tr>
            ))}
            {sortedAlerts.length === 0 && (
              <tr>
                <td colSpan={6} className="px-3 py-4 text-center text-slate-400">
                  No alerts in the last 30 days
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {selectedAlert && (
        <AlertDetailsModal
          alert={selectedAlert}
          onClose={() => setSelectedAlert(null)}
        />
      )}
    </div>
  );
}
