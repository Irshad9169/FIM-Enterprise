import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchBaselines, deleteBaseline } from "../api/dashboard";
import { Check, ShieldCheck, Clock, Loader2, Trash2 } from "lucide-react";

export default function BaselinesPage() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["baselines"],
    queryFn: fetchBaselines,
  });

  const approveMutation = useMutation({
    mutationFn: async (id: string) => {
      const token = localStorage.getItem("fim_token");
      const res = await fetch(`/api/v1/baselines/${id}/approve`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (!res.ok) throw new Error(await res.text() || "Failed to approve");
      return res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["baselines"] }),
    onError: (err) => alert("Error approving baseline: " + err),
  });

  const deleteMutation = useMutation({
    mutationFn: deleteBaseline,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["baselines"] }),
    onError: (err) => alert("Error deleting baseline: " + err),
  });

  if (isLoading) return <div className="text-center py-12 text-slate-400">Loading baselines...</div>;

  const baselines = data?.baselines || [];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-slate-900 p-4 rounded-lg border border-slate-800">
        <div>
          <h1 className="text-xl font-bold text-white">Baselines</h1>
          <p className="text-slate-400 text-sm">Approved file states for integrity comparison</p>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <table className="w-full text-sm text-left text-slate-300">
          <thead className="bg-slate-950/50 text-slate-400 font-semibold uppercase text-xs border-b border-slate-800">
            <tr>
              <th className="px-6 py-4">Agent ID</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4">Active</th>
              <th className="px-6 py-4">Created</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800">
            {baselines.map((baseline: any) => (
              <tr key={baseline.id} className="hover:bg-slate-800/50">
                <td className="px-6 py-4 font-mono text-xs">{baseline.agent_id}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded text-xs border uppercase ${
                    baseline.status === 'approved' ? 'bg-green-900/30 text-green-400 border-green-800' : 'bg-yellow-900/30 text-yellow-400 border-yellow-800'
                  }`}>
                    {baseline.status || 'PENDING'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  {baseline.is_active ? <ShieldCheck size={16} className="text-green-400" /> : <span className="text-slate-600">-</span>}
                </td>
                <td className="px-6 py-4 text-slate-400 flex items-center gap-2">
                  <Clock size={14} />
                  {new Date(baseline.created_at).toLocaleDateString()}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end items-center gap-2">
                    {baseline.status !== 'approved' && (
                      <button
                        onClick={() => approveMutation.mutate(baseline.id)}
                        disabled={approveMutation.isPending}
                        className="px-3 py-1.5 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 flex items-center gap-1 disabled:opacity-50 transition-colors"
                      >
                        {approveMutation.isPending ? <Loader2 size={12} className="animate-spin" /> : <Check size={12} />}
                        Approve
                      </button>
                    )}
                    <button
                      onClick={() => {
                        if(confirm('Delete this baseline?')) deleteMutation.mutate(baseline.id);
                      }}
                      className="p-2 text-red-400 hover:bg-red-900/20 rounded transition-colors"
                      title="Delete Baseline"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
