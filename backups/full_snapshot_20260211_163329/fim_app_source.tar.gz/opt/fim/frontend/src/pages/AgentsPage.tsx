import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchAgents, triggerScan } from "../api/dashboard";

export default function AgentsPage() {
  const [sortField, setSortField] = useState<string>("hostname");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc");
  const [scanningAgent, setScanningAgent] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { data, isLoading, error } = useQuery({
    queryKey: ["agents"],
    queryFn: fetchAgents,
  });

  const scanMutation = useMutation({
    mutationFn: ({ agentId, force }: { agentId: string; force: boolean }) => 
      triggerScan(agentId, force),
    onSuccess: () => {
      alert("Scan request sent successfully!");
      setScanningAgent(null);
      queryClient.invalidateQueries({ queryKey: ["agents"] });
    },
    onError: (error: any, { agentId, force }) => {
      const message = error.response?.data?.detail || "Failed to trigger scan";
      
      // If cooldown error and not forced, offer force option
      if (message.includes("Wait") && !force) {
        if (confirm(`${message}\n\nForce scan anyway?`)) {
          scanMutation.mutate({ agentId, force: true });
        } else {
          setScanningAgent(null);
        }
      } else {
        alert(message);
        setScanningAgent(null);
      }
    },
  });

  const handleScan = (agentId: string) => {
    setScanningAgent(agentId);
    scanMutation.mutate({ agentId, force: false });
  };

  if (isLoading) return <div className="text-center py-8">Loading agents...</div>;
  if (error) return <div className="text-center py-8 text-red-400">Error loading agents</div>;

  const agents = data?.agents || [];

  const sortedAgents = [...agents].sort((a, b) => {
    const aVal = a[sortField as keyof typeof a];
    const bVal = b[sortField as keyof typeof b];
    
    if (sortOrder === "asc") {
      return (aVal || 0) > (bVal || 0) ? 1 : -1;
    } else {
      return (aVal || 0) < (bVal || 0) ? 1 : -1;
    }
  });

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortOrder("asc");
    }
  };

  const SortIcon = ({ field }: { field: string }) => {
    if (sortField !== field) return <span className="text-slate-600">⇅</span>;
    return <span className="text-sky-400">{sortOrder === "asc" ? "↑" : "↓"}</span>;
  };

  const exportToCSV = () => {
    const headers = ["Hostname", "IP Address", "Status", "Last Heartbeat"];
    const rows = agents.map((a: any) => [
      a.hostname,
      a.ip_address || "",
      a.status,
      a.last_heartbeat || "",
    ]);

    const csv = [
      headers.join(","),
      ...rows.map((row: any[]) => row.map((cell) => `"${cell}"`).join(",")),
    ].join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `fim-agents-${new Date().toISOString().split("T")[0]}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-semibold">Agents</h1>
        <button
          onClick={exportToCSV}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded text-sm border border-slate-600"
        >
          📥 Export CSV
        </button>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
        <table className="min-w-full text-sm">
          <thead className="bg-slate-800 text-slate-300">
            <tr>
              <th
                className="px-3 py-2 text-left cursor-pointer hover:bg-slate-700"
                onClick={() => handleSort("hostname")}
              >
                Hostname <SortIcon field="hostname" />
              </th>
              <th
                className="px-3 py-2 text-left cursor-pointer hover:bg-slate-700"
                onClick={() => handleSort("ip_address")}
              >
                IP Address <SortIcon field="ip_address" />
              </th>
              <th
                className="px-3 py-2 cursor-pointer hover:bg-slate-700"
                onClick={() => handleSort("status")}
              >
                Status <SortIcon field="status" />
              </th>
              <th className="px-3 py-2">Last Heartbeat</th>
              <th className="px-3 py-2 text-center">Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedAgents.map((a: any) => (
              <tr key={a.id} className="border-t border-slate-800 hover:bg-slate-800/50">
                <td className="px-3 py-2 font-medium">{a.hostname}</td>
                <td className="px-3 py-2 text-slate-300">{a.ip_address || "-"}</td>
                <td className="px-3 py-2 text-center">
                  <span
                    className={`px-2 py-1 rounded-full text-xs ${
                      a.status === "online"
                        ? "bg-emerald-900/40 text-emerald-300 border border-emerald-700"
                        : "bg-slate-800 text-slate-300 border border-slate-600"
                    }`}
                  >
                    {a.status}
                  </span>
                </td>
                <td className="px-3 py-2 text-slate-300 text-xs">
                  {a.last_heartbeat ? new Date(a.last_heartbeat).toLocaleString() : "-"}
                </td>
                <td className="px-3 py-2 text-center">
                  <button
                    onClick={() => handleScan(a.id)}
                    disabled={scanningAgent === a.id}
                    className="px-3 py-1 bg-sky-600 hover:bg-sky-500 disabled:bg-slate-700 disabled:text-slate-500 rounded text-xs font-medium transition-colors"
                  >
                    {scanningAgent === a.id ? "⏳ Scanning..." : "🔍 Scan Now"}
                  </button>
                </td>
              </tr>
            ))}
            {sortedAgents.length === 0 && (
              <tr>
                <td colSpan={5} className="px-3 py-4 text-center text-slate-400">
                  No agents registered.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
