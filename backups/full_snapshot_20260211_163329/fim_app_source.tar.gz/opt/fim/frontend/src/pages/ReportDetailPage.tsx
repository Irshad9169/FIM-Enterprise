import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { updateReportStatus } from "../api/dashboard";
import { ArrowLeft, FileText, CheckCircle, ChevronDown, Save, Link as LinkIcon, ExternalLink, Server, Layers, Lock } from "lucide-react";
import { useState, useEffect } from "react";

export default function ReportDetailPage() {
  const { reportId } = useParams<{ reportId: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [groupNotes, setGroupNotes] = useState<Record<string, string>>({});
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  const { data: report, isLoading, refetch } = useQuery({
    queryKey: ["report", reportId],
    queryFn: async () => {
        const token = localStorage.getItem("fim_token");
        const res = await fetch(`/api/v1/reports/${reportId}`, { headers: { Authorization: `Bearer ${token}` } });
        if (!res.ok) throw new Error("Load failed");
        return res.json();
    }
  });

  useEffect(() => {
    if (report?.groups) {
      const n: Record<string, string> = {};
      report.groups.forEach((g: any) => { n[g.id] = g.notes || ""; });
      setGroupNotes(n);
    }
  }, [report]);

  if (isLoading) return <div className="p-12 text-center text-slate-400 font-mono">Loading Data...</div>;
  if (!report) return <div className="p-12 text-center text-red-400">Report not found.</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <button onClick={() => navigate('/reports')} className="px-4 py-2 bg-slate-800 text-white rounded text-sm flex items-center gap-2 hover:bg-slate-700 transition-colors"><ArrowLeft size={16} /> Back</button>
        <div className="flex gap-2">
            <button onClick={() => window.open(`/api/v1/reports/${reportId}/export?format=txt`, '_blank')} className="px-4 py-2 bg-slate-800 text-slate-200 border rounded text-sm flex items-center gap-2 hover:bg-slate-700"><FileText size={16} /> View Text</button>
            <button onClick={() => updateReportStatus(reportId!, 'reviewed').then(() => refetch())} className="px-4 py-2 bg-green-600 text-white rounded text-sm flex items-center gap-2 hover:bg-green-700 font-bold"><CheckCircle size={16} /> Mark Reviewed</button>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 p-6 rounded shadow-sm">
        <h1 className="text-2xl font-bold text-white">FIM Report - {report.report_date}</h1>
        <div className="flex gap-8 mt-4">
            <SummaryItem label="Status" value={report.status} color="text-sky-400" />
            <SummaryItem label="Modified" value={report.summary?.changed_files || 0} color="text-yellow-500" />
            <SummaryItem label="Added" value={report.summary?.added_files || 0} color="text-green-500" />
            <SummaryItem label="Removed" value={report.summary?.removed_files || 0} color="text-red-500" />
        </div>
      </div>

      {report.groups?.map((group: any) => (
        <div key={group.id} className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden mb-8 shadow-xl">
          <div className="p-4 bg-slate-800/40 border-b border-slate-800 flex items-center gap-3">
              <div className="p-2 bg-blue-600/20 rounded-lg text-blue-400"><Layers size={20}/></div>
              <div className="flex-1">
                <div className="text-white font-bold">{group.id === "UNIQUE" ? "Forensics per Server" : `Ticket Group: ${group.id}`}</div>
                <div className="flex flex-wrap gap-2 mt-1">
                  {group.agents.map((a: string) => (
                    <span key={a} className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700 flex items-center gap-1"><Server size={10} /> {a}</span>
                  ))}
                </div>
              </div>
              <button onClick={() => setCollapsed(p => ({...p, [group.id]: !p[group.id]}))}>
                 <ChevronDown className={`text-slate-500 transition-transform ${collapsed[group.id] ? '' : 'rotate-180'}`} />
              </button>
          </div>

          {!collapsed[group.id] && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-0">
              <div className="lg:col-span-3 p-4 space-y-4 max-h-[600px] overflow-y-auto border-r border-slate-800 bg-slate-950/30">
                {group.details.map((d: any, idx: number) => (
                  <div key={idx} className="border-l-4 border-yellow-600 p-4 bg-slate-900 rounded-r text-sm font-mono relative">
                      <div className="font-bold text-yellow-500 text-sm mb-2">modified — <span className="text-pink-400 normal-case">{d.file_path}</span></div>
                      <div className="grid grid-cols-1 gap-1 text-slate-400 text-[10px] break-all">
                        <div>HASH: {d.baseline_hash || 'N/A'} → {d.current_hash || 'N/A'}</div>
                        <div>SIZE: {d.baseline_size} → {d.current_size} bytes</div>
                        <div>TIME: {d.baseline_mtime || 'N/A'} → {d.current_mtime || 'N/A'}</div>
                      </div>
                  </div>
                ))}
              </div>

              <div className="p-4 bg-slate-900 space-y-6 border-l border-slate-800">
                <div>
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Linked Tickets</h4>
                  {group.tickets?.map((t: any, tidx: number) => (
                    <div key={tidx} className={`p-2 border rounded mb-2 flex items-start gap-2 ${t.is_linked ? 'bg-blue-600/20 border-blue-500' : 'bg-slate-950 border-slate-800'}`}>
                      <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center text-blue-400 font-bold text-[10px]">
                              <span>{t.external_id}</span>
                              <a href={t.url} target="_blank" rel="noreferrer" className="text-slate-500 hover:text-white"><ExternalLink size={10}/></a>
                          </div>
                          <div className="text-[9px] text-slate-400 truncate">{t.summary}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <div>
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Justification {group.is_locked && <Lock size={10} className="inline ml-1 text-red-500" />}</h4>
                  <textarea 
                    disabled={group.is_locked}
                    className={`w-full border border-slate-800 rounded p-3 text-xs bg-slate-950 text-slate-100 outline-none h-48 focus:border-blue-500 ${group.is_locked ? 'bg-slate-800/40 text-slate-200' : ''}`}
                    value={groupNotes[group.id] || ""}
                    onChange={e => setGroupNotes({...groupNotes, [group.id]: e.target.value})}
                  ></textarea>
                  {!group.is_locked && (
                    <button onClick={async () => {
                        const token = localStorage.getItem("fim_token");
                        await fetch(`/api/v1/reports/${reportId}/group-notes`, {
                            method: 'PATCH',
                            headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
                            body: JSON.stringify({ agents: group.agents, notes: groupNotes[group.id] })
                        });
                        alert("Notes saved."); refetch();
                    }} className="w-full mt-2 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded">Commit & Lock</button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function SummaryItem({ label, value, color }: any) {
    return (
        <div>
            <div className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-1">{label}</div>
            <div className={`text-xl font-bold uppercase ${color}`}>{value}</div>
        </div>
    )
}
