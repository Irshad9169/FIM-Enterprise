import os, time, logging, hashlib, urllib.parse, base64, re
from subprocess import Popen, PIPE
from typing import Optional

logger = logging.getLogger("sso_debug")

class SSOManager:
    def __init__(self):
        self.OPENSSL_BIN = '/usr/bin/openssl'
        self.SSO_SERVER_URL = 'https://auth.qa.int.untd.com/bin/sso'
        self.PUBLIC_KEY_PATH = '/opt/fim/config/sso-public.pem'
        # The Private Key is used to sign outbound requests to CMR/RT
        self.PRIVATE_KEY_PATH = '/opt/fim/config/fim-private.pem'
        self.APP_ID = 'FIM_ENTERPRISE' 

    def run_openssl_command(self, data: bytes, args: list) -> Optional[bytes]:
        cmd = [self.OPENSSL_BIN] + args
        try:
            p = Popen(cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE)
            stdout, stderr = p.communicate(input=data)
            if p.returncode != 0:
                logger.error(f"OpenSSL Error: {stderr.decode().strip()}")
                return None
            return stdout
        except Exception as e:
            logger.error(f"Subprocess crash: {e}")
            return None

    def create_outbound_token(self, username: str) -> str:
        """
        Creates a signed token to talk to CMR/RT as the current user.
        Format: username|appID|timestamp|signature
        """
        ts = int(time.time())
        data_to_sign = f"{username}|{self.APP_ID}|{ts}"
        
        # 1. Generate MD5 digest of the identity string
        digest = hashlib.md5(data_to_sign.encode()).digest()
        
        # 2. Sign using FIM Private Key
        if not os.path.exists(self.PRIVATE_KEY_PATH):
            logger.error(f"Private key missing at {self.PRIVATE_KEY_PATH}")
            return "MISSING_KEY"

        # Sign the digest
        signature = self.run_openssl_command(digest, ['rsautl', '-sign', '-inkey', self.PRIVATE_KEY_PATH])
        
        if not signature:
            return "SIGNING_FAILED"
            
        # 3. Base64 encode and construct token
        sig_b64 = base64.b64encode(signature).decode().strip()
        full_token = f"{username}|{self.APP_ID}|{ts}|{sig_b64}"
        
        return urllib.parse.quote(full_token)

    def verify_signature(self, data: str, signature_b64: str) -> bool:
        """Verify incoming signature from Corporate SSO"""
        clean_b64 = re.sub(r'[^A-Za-z0-9+/=]', '', signature_b64)
        decoded_sig = base64.b64decode(clean_b64)
        if len(decoded_sig) > 64: decoded_sig = decoded_sig[:64]

        # Use -raw to handle legacy padding
        decrypted_block = self.run_openssl_command(decoded_sig, ['rsautl', '-verify', '-pubin', '-inkey', self.PUBLIC_KEY_PATH, '-raw'])
        if not decrypted_block: return False

        expected_digest = hashlib.md5(data.encode('utf-8')).digest()
        return expected_digest in decrypted_block

    def get_user_from_token(self, sso_token: str) -> Optional[str]:
        if not sso_token: return None
        try:
            token = urllib.parse.unquote(urllib.parse.unquote(sso_token)).strip()
            parts = token.split('|')
            if len(parts) < 4: return None
            username, app_id, ts = parts[0], parts[1], parts[2]
            signature = "|".join(parts[3:]) 
            if app_id != self.APP_ID: return None
            if self.verify_signature(f"{username}|{app_id}|{ts}", signature):
                return username
        except: pass
        return None

    def get_login_url(self, redirect_url: str) -> str:
        params = {'origin_name': 'FIM', 'origin_url': redirect_url, 'origin_id': self.APP_ID}
        return f"{self.SSO_SERVER_URL}?{urllib.parse.urlencode(params)}"
