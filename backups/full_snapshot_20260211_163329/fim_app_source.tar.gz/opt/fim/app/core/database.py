from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)
Base = declarative_base()

class DatabaseManager:
    def __init__(self):
        self.engine = create_async_engine(
            settings.database_url,
            pool_size=50,
            max_overflow=100,
            pool_timeout=30,
            pool_recycle=3600,
            pool_pre_ping=True
        )
        self.async_session = async_sessionmaker(
            self.engine,
            class_=AsyncSession,
            expire_on_commit=False
        )

    async def initialize(self):
        pass

    async def close(self):
        if self.engine:
            await self.engine.dispose()

db_manager = DatabaseManager()

async def get_db():
    session = db_manager.async_session()
    try:
        yield session
    except Exception as e:
        await session.rollback()
        raise e
    finally:
        await session.close()
