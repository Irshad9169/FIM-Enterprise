"""
Change Detection Service - The FIM Brain
Compares scans against baselines and generates alerts with Whitelisting
"""
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_
from typing import Dict, List, Optional, Set
import logging
import uuid
import hashlib
import json
import re
import fnmatch
from datetime import datetime

from app.models.models import Scan, Baseline, Alert, WhitelistRule

logger = logging.getLogger(__name__)

class ChangeDetector:
    """Compares scans against baselines and generates alerts"""

    @staticmethod
    async def process_scan(scan_id: uuid.UUID, db: AsyncSession) -> Dict:
        """Process a new scan and detect changes"""
        result = await db.execute(select(Scan).where(Scan.id == scan_id))
        scan = result.scalar_one_or_none()

        if not scan or not scan.scan_data:
            return {'error': 'Scan not found or no data'}

        result = await db.execute(
            select(Baseline)
            .where(Baseline.agent_id == scan.agent_id)
            .where(Baseline.is_active == True)
            .limit(1)
        )
        baseline = result.scalar_one_or_none()

        # 1. AUTO-CREATE BASELINE IF MISSING
        if not baseline:
            data_str = json.dumps(scan.scan_data, sort_keys=True)
            checksum = hashlib.sha256(data_str.encode()).hexdigest()
            new_baseline = Baseline(
                id=uuid.uuid4(),
                agent_id=scan.agent_id,
                baseline_name=f"Initial Baseline - {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                baseline_data=scan.scan_data,
                file_count=scan.files_scanned,
                total_size_bytes=0,
                checksum=checksum,
                is_active=True,
                status='pending',
                created_at=datetime.utcnow()
            )
            db.add(new_baseline)
            return {'status': 'baseline_created', 'message': 'Initial baseline created'}

        # 2. COMPARE FILES
        changes = ChangeDetector._compare_files(
            baseline.baseline_data.get('files', []),
            scan.scan_data.get('files', [])
        )

        # 3. FETCH WHITELIST RULES (Exclusions)
        # Fetch global rules AND agent-specific rules for this agent
        whitelist_query = await db.execute(
            select(WhitelistRule).where(
                and_(
                    WhitelistRule.is_active == True,
                    (WhitelistRule.scope == 'global') | (WhitelistRule.agent_id == scan.agent_id)
                )
            )
        )
        whitelist_rules = whitelist_query.scalars().all()

        # 4. FETCH EXISTING OPEN ALERTS (Deduplication)
        open_alerts_query = await db.execute(
            select(Alert.file_path, Alert.alert_type)
            .where(and_(Alert.agent_id == scan.agent_id, Alert.status == 'open'))
        )
        existing_alerts: Set[tuple] = {
            (row.file_path, row.alert_type) for row in open_alerts_query.fetchall()
        }

        # 5. CREATE ALERTS (Filtered by Whitelist and Duplicates)
        alerts_created = 0
        whitelisted_count = 0
        skipped_duplicates = 0
        
        for change in changes:
            alert_type = f"file_{change['type']}"
            path = change['path']

            # Check if duplicated
            if (path, alert_type) in existing_alerts:
                skipped_duplicates += 1
                continue

            # Check if whitelisted (EXCLUSIONS)
            is_excluded = False
            for rule in whitelist_rules:
                if ChangeDetector._check_whitelist_match(path, rule):
                    is_excluded = True
                    # Increment match count for rule (optional background task)
                    rule.match_count = (rule.match_count or 0) + 1
                    rule.last_matched_at = datetime.utcnow()
                    break
            
            if is_excluded:
                whitelisted_count += 1
                continue

            try:
                await ChangeDetector._create_alert(scan.agent_id, change, db)
                alerts_created += 1
            except Exception as e:
                logger.error(f"Failed to create alert: {e}")

        return {
            'status': 'completed',
            'changes_detected': len(changes),
            'alerts_created': alerts_created,
            'whitelisted_ignored': whitelisted_count,
            'skipped_duplicates': skipped_duplicates
        }

    @staticmethod
    def _check_whitelist_match(path: str, rule: WhitelistRule) -> bool:
        """Check if a path matches a whitelist rule"""
        try:
            if rule.rule_type == 'path':
                return path == rule.match_value
            elif rule.rule_type == 'glob':
                # Use fnmatch for glob patterns like /var/log/*
                return fnmatch.fnmatch(path, rule.match_value)
            elif rule.rule_type == 'regex':
                # Use regex for patterns like ^/opt/fim/.*
                return bool(re.match(rule.match_value, path))
        except Exception as e:
            logger.error(f"Error matching rule {rule.id}: {e}")
        return False

    @staticmethod
    def _compare_files(baseline_files: List[Dict], scan_files: List[Dict]) -> List[Dict]:
        baseline_map = {f['path']: f for f in baseline_files}
        scan_map = {f['path']: f for f in scan_files}
        changes = []

        for path, scan_file in scan_map.items():
            baseline_file = baseline_map.get(path)
            if not baseline_file:
                changes.append({
                    'type': 'created', 'path': path, 
                    'severity': ChangeDetector._severity_for_new_file(path),
                    'current_state': scan_file, 'previous_state': None
                })
            elif ChangeDetector._file_changed(baseline_file, scan_file):
                changes.append({
                    'type': 'modified', 'path': path, 'severity': 'medium',
                    'current_state': scan_file, 'previous_state': baseline_file,
                    'changes': ChangeDetector._get_change_details(baseline_file, scan_file)
                })

        for path, baseline_file in baseline_map.items():
            if path not in scan_map:
                changes.append({
                    'type': 'deleted', 'path': path, 'severity': 'high',
                    'current_state': None, 'previous_state': baseline_file
                })
        return changes

    @staticmethod
    def _file_changed(baseline: Dict, current: Dict) -> bool:
        return (
            baseline.get('hash') != current.get('hash') or
            baseline.get('permissions') != current.get('permissions') or
            baseline.get('owner') != current.get('owner') or
            baseline.get('group') != current.get('group') or
            baseline.get('size') != current.get('size')
        )

    @staticmethod
    def _get_change_details(baseline: Dict, current: Dict) -> Dict:
        details = {}
        if baseline.get('hash') != current.get('hash'):
            details['hash'] = {'old': baseline.get('hash'), 'new': current.get('hash')}
        if baseline.get('size') != current.get('size'):
            details['size'] = {'old': baseline.get('size'), 'new': current.get('size')}
        return details

    @staticmethod
    def _severity_for_new_file(path: str) -> str:
        if path.startswith(('/etc', '/bin', '/sbin', '/usr/bin', '/usr/sbin')):
            return 'high'
        return 'medium'

    @staticmethod
    async def _create_alert(agent_id: uuid.UUID, change: Dict, db: AsyncSession):
        alert = Alert(
            id=uuid.uuid4(),
            agent_id=agent_id,
            file_path=change['path'],
            alert_type=f"file_{change['type']}",
            severity=change['severity'],
            status='open',
            previous_state=change.get('previous_state'),
            current_state=change.get('current_state'),
            change_details={
                'change_type': change['type'],
                'detected_at': datetime.utcnow().isoformat(),
                'changes': change.get('changes', {})
            },
            detected_at=datetime.utcnow(),
            created_at=datetime.utcnow()
        )
        db.add(alert)
