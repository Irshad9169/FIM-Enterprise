import logging
import httpx
import re
from datetime import datetime
from app.core.sso_manager import SSOManager
from sqlalchemy import text

logger = logging.getLogger("ticket_linker")
sso = SSOManager()

# Use HTTP for lookup (matches your old working config)
RT_LOOKUP_URL = "http://rtapi.int.untd.com/cgi-bin/rt.cgi"
# Use HTTPS for updates (matches your screenshot)
RT_UPDATE_URL = "https://rtapi.int.untd.com/cgi-bin/rt.cgi"

class TicketLinkerService:
    @staticmethod
    async def find_daily_review_ticket(report_date, token):
        date_str = report_date.strftime("%Y/%m/%d")
        subject_pattern = f"Daily FIM Log Security Review - {date_str}"
        try:
            async with httpx.AsyncClient(verify=False) as client:
                params = {'query': f"Subject = '{subject_pattern}'", 'sso_token': token}
                resp = await client.get(RT_LOOKUP_URL, params=params, timeout=5.0)
                if resp.status_code == 200 and ':' in resp.text:
                    return resp.text.split(':', 1)[0].strip()
        except Exception as e:
            logger.error(f"Failed to find daily RT ticket: {e}")
        return None

    @staticmethod
    async def post_review_to_rt(ticket_id, content, token):
        url = f"{RT_UPDATE_URL}/ticket/{ticket_id}/comment"
        try:
            data = {"content": content, "Action": "comment"}
            params = {"sso_token": token}
            async with httpx.AsyncClient(verify=False) as client:
                resp = await client.post(url, data=data, params=params, timeout=10.0)
                return resp.status_code == 200
        except:
            return False

    @staticmethod
    async def resolve_rt_ticket(ticket_id, token):
        url = f"{RT_UPDATE_URL}/ticket/{ticket_id}/edit"
        # We try to set the status and also a default task type to satisfy RT requirements
        payload = "Status: resolved\nCF-Task Type: Security Review"
        data = {"content": payload}
        params = {"sso_token": token}
        try:
            async with httpx.AsyncClient(verify=False) as client:
                resp = await client.post(url, data=data, params=params, timeout=10.0)
                return "updated" in resp.text.lower() or resp.status_code == 200
        except:
            return False

    @staticmethod
    async def correlate_report(report_id, agent_list, username, db):
        token = sso.create_outbound_token(username)
        async with httpx.AsyncClient(verify=False) as client:
            for hostname in agent_list:
                try:
                    cmr_url = "https://phantom.int.untd.com/bin/phantom"
                    params = {'action': 'display', 'type': 'runadvancedsearch', 'hostname': hostname, 'sso_token': token}
                    resp = await client.get(cmr_url, params=params, timeout=10.0)
                    if resp.status_code == 200:
                        cmr_ids = set(re.findall(r'#(\d{6})', resp.text))
                        for cid in cmr_ids:
                            query = text("INSERT INTO fim.report_tickets (id, report_id, agent_hostname, source, external_id, summary, url, linked_at) VALUES (gen_random_uuid(), :rid, :h, 'cmr', :eid, 'CMR Lookup', :u, NOW()) ON CONFLICT DO NOTHING")
                            await db.execute(query, {"rid": report_id, "h": hostname, "eid": cid, "u": f"{cmr_url}?id={cid}"})
                except: pass
