from pydantic import BaseModel, UUID4
from datetime import date, datetime
from typing import Optional, List, Dict, Any

class DailyReportSummary(BaseModel):
    added_files: int = 0
    removed_files: int = 0
    changed_files: int = 0
    class Config: from_attributes = True

class DailyReportResponse(BaseModel):
    id: UUID4
    report_date: date
    agents: Optional[List[str]] = []
    summary: DailyReportSummary
    status: Optional[str] = "pending"
    total_changes: int = 0
    created_at: datetime
    rt_ticket_id: Optional[str] = None
    class Config: from_attributes = True

class ReportChangeDetail(BaseModel):
    file_path: str
    agent_hostname: Optional[str] = None
    baseline_mtime: Optional[str] = None
    current_mtime: Optional[str] = None
    baseline_hash: Optional[str] = None
    current_hash: Optional[str] = None
    baseline_size: Optional[int] = None
    current_size: Optional[int] = None
    analyst_notes: Optional[str] = None
    class Config: from_attributes = True

class TicketDetail(BaseModel):
    id: str
    source: str
    external_id: str
    summary: str
    url: str
    agent_hostname: str
    is_linked: bool
    class Config: from_attributes = True

class DailyReportDetail(DailyReportResponse):
    groups: List[Dict[str, Any]] = []
    class Config: from_attributes = True

class GenerateReportRequest(BaseModel):
    report_date: Optional[date] = None

class UpdateNotesRequest(BaseModel):
    analyst_notes: str

class UpdateStatusRequest(BaseModel):
    status: str
