"""
Database Models - Complete Comprehensive Version
"""
from sqlalchemy import Column, String, Integer, Boolean, DateTime, Text, BigInteger, UUID, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB, ARRAY
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
from app.core.database import Base

class User(Base):
    __tablename__ = "users"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username = Column(String(100), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    full_name = Column(String(255))
    role = Column(String(50), default="viewer")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Agent(Base):
    __tablename__ = "agents"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    hostname = Column(String(255), unique=True, nullable=False)
    ip_address = Column(String(50))
    os_type = Column(String(50))
    os_version = Column(String(100))
    agent_version = Column(String(20))
    status = Column(String(20), default="offline")
    last_heartbeat = Column(DateTime)
    tags = Column(JSONB)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    expected_heartbeat_interval = Column(Integer, default=300)
    heartbeat_timeout = Column(Integer, default=600)
    is_healthy = Column(Boolean, default=True)
    last_heartbeat_alert = Column(DateTime)
    last_scan_at = Column(DateTime)
    scan_count = Column(Integer, default=0)

class Policy(Base):
    __tablename__ = "policies"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), unique=True, nullable=False)
    description = Column(Text)
    paths = Column(ARRAY(Text))
    exclude_patterns = Column(ARRAY(Text))
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id = Column(UUID(as_uuid=True), ForeignKey("fim.agents.id", ondelete="CASCADE"))
    policy_id = Column(UUID(as_uuid=True), ForeignKey("fim.policies.id"))
    alert_type = Column(String(50), nullable=False)
    severity = Column(String(20), nullable=False)
    file_path = Column(String(1024), nullable=False)
    previous_state = Column(JSONB)
    current_state = Column(JSONB)
    change_details = Column(JSONB)
    status = Column(String(20), default="open")
    assigned_to = Column(UUID(as_uuid=True), ForeignKey("fim.users.id"))
    resolution_notes = Column(Text)
    detected_at = Column(DateTime, default=datetime.utcnow)
    acknowledged_at = Column(DateTime)
    resolved_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_whitelisted = Column(Boolean, default=False)
    whitelist_rule_id = Column(UUID(as_uuid=True), ForeignKey("fim.whitelist_rules.id"))
    triggered_by_rule = Column(UUID(as_uuid=True), ForeignKey("fim.alert_rules.id"))
    acknowledged_by = Column(UUID(as_uuid=True), ForeignKey("fim.users.id"))

class DailyReport(Base):
    __tablename__ = "reports"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    report_date = Column(DateTime, unique=True, nullable=False)
    agent_list = Column(ARRAY(String))
    total_added = Column(Integer, default=0)
    total_removed = Column(Integer, default=0)
    total_changed = Column(Integer, default=0)
    total_changes = Column(Integer, default=0)
    total_servers = Column(Integer, default=0)
    status = Column(String(20), default='pending')
    rt_ticket_id = Column(String(50))
    generated_by = Column(UUID(as_uuid=True), ForeignKey('fim.users.id'))
    created_at = Column(DateTime, default=datetime.utcnow)

class ReportChange(Base):
    __tablename__ = "report_changes"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    report_id = Column(UUID(as_uuid=True), ForeignKey('fim.reports.id', ondelete='CASCADE'), nullable=False)
    alert_id = Column(UUID(as_uuid=True), ForeignKey('fim.alerts.id'))
    agent_hostname = Column(String(255))
    file_path = Column(Text)
    change_type = Column(String(50))
    severity = Column(String(20))
    baseline_hash = Column(String(64))
    current_hash = Column(String(64))
    baseline_size = Column(BigInteger)
    current_size = Column(BigInteger)
    baseline_mtime = Column(DateTime)
    current_mtime = Column(DateTime)
    analyst_notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("fim.users.id"))
    username = Column(String(100))
    action = Column(String(100), nullable=False)
    resource_type = Column(String(50))
    resource_id = Column(UUID(as_uuid=True))
    details = Column(JSONB)
    ip_address = Column(String(50))
    timestamp = Column(DateTime, default=datetime.utcnow)

class Baseline(Base):
    __tablename__ = "baselines"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id = Column(UUID(as_uuid=True), ForeignKey("fim.agents.id", ondelete="CASCADE"))
    baseline_data = Column(JSONB)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    status = Column(String(20), default='pending')
    is_approved = Column(Boolean, default=False)

class Scan(Base):
    __tablename__ = "scans"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id = Column(UUID(as_uuid=True), ForeignKey('fim.agents.id'))
    scan_data = Column(JSONB)
    started_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

class WhitelistRule(Base):
    __tablename__ = "whitelist_rules"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_name = Column(String(255), unique=True)
    rule_type = Column(String(50))
    match_value = Column(Text)
    is_active = Column(Boolean, default=True)
    scope = Column(String(20), default='global')
    agent_id = Column(UUID(as_uuid=True), ForeignKey("fim.agents.id", ondelete="CASCADE"))

class ScanRequest(Base):
    __tablename__ = "scan_requests"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    agent_id = Column(UUID(as_uuid=True), ForeignKey("fim.agents.id", ondelete="CASCADE"))
    status = Column(String(20), default="pending")
    requested_at = Column(DateTime, default=datetime.utcnow)

class RuleExecution(Base):
    __tablename__ = "rule_executions"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_id = Column(UUID(as_uuid=True), ForeignKey("fim.alert_rules.id", ondelete="CASCADE"))
    executed_at = Column(DateTime, default=datetime.utcnow)

class ComplianceFramework(Base):
    __tablename__ = "compliance_frameworks"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(100), unique=True)

class AlertRule(Base):
    __tablename__ = "alert_rules"
    __table_args__ = {"schema": "fim"}
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
