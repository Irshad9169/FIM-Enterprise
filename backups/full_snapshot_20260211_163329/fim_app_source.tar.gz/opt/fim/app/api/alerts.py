from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, text
from typing import Optional, List
from datetime import datetime, timedelta

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import User, Alert

router = APIRouter()

@router.get("")
async def list_alerts(
    skip: int = 0,
    limit: int = 100,
    days: Optional[int] = Query(None, description="Filter alerts by last N days"),
    severity: Optional[str] = None,
    status: Optional[str] = None,
    agent_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """List alerts with filtering"""
    
    query = select(Alert)
    
    # Filter by date range if days provided
    if days:
        cutoff_date = datetime.now() - timedelta(days=days)
        query = query.where(Alert.created_at >= cutoff_date)
        
    if severity:
        query = query.where(Alert.severity == severity)
        
    if status:
        query = query.where(Alert.status == status)
        
    if agent_id:
        query = query.where(Alert.agent_id == agent_id)
        
    query = query.order_by(desc(Alert.created_at)).offset(skip).limit(limit)
    
    result = await db.execute(query)
    alerts = result.scalars().all()
    
    return {"alerts": alerts, "total": len(alerts)}
