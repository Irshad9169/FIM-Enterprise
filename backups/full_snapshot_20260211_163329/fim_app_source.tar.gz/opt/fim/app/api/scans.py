"""
Scan Results Endpoints
"""
from fastapi import APIRouter, Depends, HTTPException, Query
from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, text
from pydantic import BaseModel
from typing import List, Optional, Dict
import uuid
import logging

from app.core.database import get_db
from app.models.models import Agent, Scan
from app.services.change_detector import ChangeDetector

logger = logging.getLogger(__name__)
router = APIRouter()

class ScanSubmitRequest(BaseModel):
    agent_id: str
    timestamp: str
    files: List[Dict]
    total_files: int

@router.post("/submit")
async def submit_scan(request: ScanSubmitRequest, db: AsyncSession = Depends(get_db)):
    # ... (Keep existing submit logic logic, it works fine) ...
    # Re-pasting the submit logic for completeness
    try:
        agent_uuid = uuid.UUID(request.agent_id)
    except ValueError:
        raise HTTPException(400, "Invalid agent ID")

    result = await db.execute(select(Agent).where(Agent.id == agent_uuid))
    agent = result.scalar_one_or_none()
    if not agent: raise HTTPException(404, "Agent not found")

    try:
        timestamp_str = request.timestamp.replace('Z', '+00:00')
        dt_aware = datetime.fromisoformat(timestamp_str)
        dt_utc = dt_aware.astimezone(timezone.utc).replace(tzinfo=None)
    except: dt_utc = datetime.utcnow()

    scan = Scan(
        id=uuid.uuid4(),
        agent_id=agent_uuid,
        scan_type="full",
        status="completed",
        files_scanned=request.total_files,
        files_changed=0,
        scan_duration=0,
        scan_data={"files": request.files},
        started_at=dt_utc,
        completed_at=datetime.utcnow()
    )
    db.add(scan)
    await db.commit()
    await db.refresh(scan)

    change_stats = {}
    try:
        change_stats = await ChangeDetector.process_scan(scan.id, db)
        scan.files_changed = change_stats.get('changes_detected', 0)
        await db.commit()
    except Exception as e:
        change_stats = {'error': str(e)}

    return {"success": True, "scan_id": str(scan.id), "change_detection": change_stats}

@router.get("")
async def list_scans(
    search: Optional[str] = None,
    limit: int = 100,
    db: AsyncSession = Depends(get_db)
):
    """List latest scan for each agent"""
    try:
        # PostgreSQL specific DISTINCT ON for latest per agent
        query_sql = """
            SELECT DISTINCT ON (s.agent_id) 
                s.id, s.agent_id, s.scan_type, s.status, s.files_scanned, 
                s.files_changed, s.started_at, s.completed_at,
                a.hostname as agent_hostname
            FROM fim.scans s
            JOIN fim.agents a ON s.agent_id = a.id
            WHERE 1=1
        """
        
        params = {}
        if search:
            query_sql += " AND a.hostname ILIKE :search"
            params['search'] = f"%{search}%"
            
        query_sql += " ORDER BY s.agent_id, s.started_at DESC"
        
        # We handle pagination in UI for this view usually, or limit the agents
        # limit here limits the number of AGENTS returned
        
        result = await db.execute(text(query_sql), params)
        rows = result.fetchall()
        
        # Apply limit manually if needed, but distinct on is tricky with limit
        scans = rows[:limit]

        return {
            "scans": [
                {
                    "id": str(r.id),
                    "agent_id": str(r.agent_id),
                    "agent_hostname": r.agent_hostname,
                    "scan_type": r.scan_type,
                    "status": r.status,
                    "files_scanned": r.files_scanned,
                    "files_changed": r.files_changed,
                    "started_at": str(r.started_at),
                    "completed_at": str(r.completed_at)
                } for r in scans
            ],
            "total": len(scans)
        }
    except Exception as e:
        logger.error(f"List scans error: {e}")
        return {"scans": [], "total": 0}

@router.get("/{scan_id}")
async def get_scan(scan_id: str, db: AsyncSession = Depends(get_db)):
    # ... (Keep existing get_scan) ...
    try:
        result = await db.execute(select(Scan).where(Scan.id == uuid.UUID(scan_id)))
        scan = result.scalar_one_or_none()
        if not scan: raise HTTPException(404, "Not found")
        return {
            "id": str(scan.id),
            "agent_id": str(scan.agent_id),
            "scan_type": scan.scan_type,
            "status": scan.status,
            "files_scanned": scan.files_scanned,
            "files_changed": scan.files_changed,
            "started_at": str(scan.started_at),
            "completed_at": str(scan.completed_at),
            "scan_data": scan.scan_data
        }
    except: raise HTTPException(404, "Not found")
