from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import User

router = APIRouter()

class AuditLogResponse(BaseModel):
    id: str
    action: str
    details: Optional[Dict[str, Any]]
    username: Optional[str]
    ip_address: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True

@router.get("")
async def list_audit_logs(
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    try:
        # Map timestamp to created_at for frontend compatibility
        query = text("""
            SELECT 
                a.id, 
                a.action, 
                a.details, 
                u.username, 
                a.ip_address, 
                a.timestamp as created_at
            FROM fim.audit_logs a
            LEFT JOIN fim.users u ON a.user_id = u.id
            ORDER BY a.timestamp DESC
            LIMIT :limit
        """)
        result = await db.execute(query, {"limit": limit})
        
        logs = []
        for row in result.fetchall():
            log = dict(row._mapping)
            # Ensure details is a dict if it's stored as JSONB
            if log['details'] is None:
                log['details'] = {}
            # Ensure id is string
            log['id'] = str(log['id'])
            logs.append(log)
            
        return logs
    except Exception as e:
        print(f"Audit log error: {e}")
        return []
