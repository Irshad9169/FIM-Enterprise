"""
Enhanced Authentication
"""
from fastapi import APIRouter, Depends, HTTPException, status, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from datetime import timedelta

from app.core.database import get_db
from app.core.security import verify_password, create_access_token
from app.core.config import settings
from app.models import User

router = APIRouter()

class LoginRequest(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict

# Simple permissions structure
ROLE_PERMISSIONS = {
    'admin': {'reports_generate': True, 'reports_review': True, 'reports_submit': True, 'reports_delete': True, 'scans_trigger': True, 'agents_manage': True, 'baselines_approve': True, 'alerts_manage': True, 'audit_logs_view': True, 'users_manage': True},
    'analyst': {'reports_generate': True, 'reports_review': True, 'reports_submit': True, 'reports_delete': False, 'scans_trigger': True, 'agents_manage': False, 'baselines_approve': True, 'alerts_manage': True, 'audit_logs_view': False, 'users_manage': False},
    'trainee': {'reports_generate': False, 'reports_review': True, 'reports_submit': True, 'reports_delete': False, 'scans_trigger': False, 'agents_manage': False, 'baselines_approve': False, 'alerts_manage': True, 'audit_logs_view': False, 'users_manage': False},
    'auditor': {'reports_generate': False, 'reports_review': False, 'reports_submit': False, 'reports_delete': False, 'scans_trigger': False, 'agents_manage': False, 'baselines_approve': False, 'alerts_manage': False, 'audit_logs_view': True, 'users_manage': False},
}

@router.post("/login", response_model=TokenResponse)
async def login(
    request: LoginRequest, 
    http_request: Request,
    db: AsyncSession = Depends(get_db)
):
    """User login"""
    try:
        # Find user
        result = await db.execute(
            select(User).where(User.username == request.username)
        )
        user = result.scalar_one_or_none()

        if not user or not verify_password(request.password, user.password_hash):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
                headers={"WWW-Authenticate": "Bearer"},
            )

        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="User account is disabled"
            )

        # Create access token
        access_token_expires = timedelta(minutes=settings.access_token_expire_minutes)
        access_token = create_access_token(
            data={
                "sub": str(user.id),
                "username": user.username,
                "role": user.role
            },
            expires_delta=access_token_expires
        )

        return {
            "access_token": access_token,
            "token_type": "bearer",
            "user": {
                "id": str(user.id),
                "username": user.username,
                "email": user.email,
                "role": user.role,
                "full_name": user.full_name,
                "permissions": ROLE_PERMISSIONS.get(user.role, {})
            }
        }
    except HTTPException:
        raise
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Login error: {str(e)}")
