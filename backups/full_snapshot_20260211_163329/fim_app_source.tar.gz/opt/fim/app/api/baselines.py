from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc, text
import uuid
import logging
from datetime import datetime

from app.core.database import get_db
from app.core.security import get_current_user
from app.models.models import User, Baseline

logger = logging.getLogger(__name__)
router = APIRouter()

@router.get("")
async def list_baselines(db: AsyncSession = Depends(get_db), u = Depends(get_current_user)):
    result = await db.execute(select(Baseline).order_by(desc(Baseline.created_at)))
    baselines = result.scalars().all()
    # Explicitly return dictionaries to ensure 'status' is included
    return {"baselines": [
        {
            "id": str(b.id),
            "agent_id": str(b.agent_id),
            "status": b.status or ('approved' if b.is_approved else 'pending'),
            "is_active": b.is_active,
            "created_at": b.created_at.isoformat() if b.created_at else None
        } for b in baselines
    ]}

@router.post("/{baseline_id}/approve")
async def approve_baseline(baseline_id: str, db: AsyncSession = Depends(get_db), u = Depends(get_current_user)):
    try:
        # Use raw SQL update to bypass any ORM or Trigger issues
        query = text("UPDATE fim.baselines SET status = 'approved', is_approved = true, is_active = true, approved_at = NOW(), approved_by = :uid WHERE id = :id")
        await db.execute(query, {"uid": u.id, "id": baseline_id})
        await db.commit()
        return {"message": "Approved"}
    except Exception as e:
        await db.rollback()
        logger.error(f"Approval error: {e}")
        raise HTTPException(500, str(e))

@router.delete("/{baseline_id}")
async def delete_baseline(baseline_id: str, db: AsyncSession = Depends(get_db), u = Depends(get_current_user)):
    await db.execute(text("DELETE FROM fim.baselines WHERE id = :id"), {"id": baseline_id})
    await db.commit()
    return {"message": "Deleted"}
