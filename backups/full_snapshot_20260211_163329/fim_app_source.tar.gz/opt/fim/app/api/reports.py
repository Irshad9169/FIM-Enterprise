from fastapi import APIRouter, Depends, HTTPException, Response, Body, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, text, or_
from datetime import date, datetime, timedelta, time
from typing import Optional, List, Dict, Any
import uuid
import json
import logging

from app.core.database import get_db
from app.models import User, AuditLog, DailyReport, ReportChange
from app.schemas.daily_report import (
    DailyReportResponse, DailyReportDetail, GenerateReportRequest, 
    UpdateNotesRequest, UpdateStatusRequest, DailyReportSummary
)
from app.core.security import get_current_user
from app.services.ticket_linker import TicketLinkerService
from app.core.sso_manager import SSOManager

logger = logging.getLogger("report_api")
router = APIRouter()
sso = SSOManager()

def clean_host(host):
    return str(host or 'unknown').split('.')[0].lower().strip()

async def find_report_obj(db, identifier):
    identifier = str(identifier).strip()
    try:
        if len(identifier) > 30:
            res = await db.execute(select(DailyReport).where(DailyReport.id == uuid.UUID(identifier)))
            return res.scalar_one_or_none()
    except: pass
    try:
        # Match YYYY-MM-DD
        res = await db.execute(select(DailyReport).where(func.date(DailyReport.report_date) == func.date(identifier)))
        return res.scalar_one_or_none()
    except: pass
    return None

@router.get("", response_model=List[DailyReportResponse])
@router.get("/", response_model=List[DailyReportResponse])
async def list_reports(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(DailyReport).order_by(DailyReport.report_date.desc()))
    return [DailyReportResponse(
        id=r.id, report_date=r.report_date, agents=r.agent_list or [],
        summary=DailyReportSummary(added_files=r.total_added, removed_files=r.total_removed, changed_files=r.total_changed),
        status=r.status, total_changes=r.total_changes, created_at=r.created_at,
        rt_ticket_id=getattr(r, 'rt_ticket_id', None)
    ) for r in result.scalars().all()]

@router.get("/{id_or_date}", response_model=DailyReportDetail)
async def get_report_grouped(id_or_date: str, db: AsyncSession = Depends(get_db)):
    r = await find_report_obj(db, id_or_date)
    if not r: raise HTTPException(404, "Report not found")
    
    res_c = await db.execute(select(ReportChange).where(ReportChange.report_id == r.id))
    all_changes = res_c.scalars().all()
    
    res_t = await db.execute(text("SELECT id, source, external_id, summary, url, agent_hostname, is_linked FROM fim.report_tickets WHERE report_id = :rid"), {"rid": r.id})
    tickets = [dict(row._mapping) for row in res_t.fetchall()]

    agent_to_group = {clean_host(t['agent_hostname']): f"{t['source'].upper()}-{t['external_id']}" for t in tickets if t['is_linked']}
    groups = {}
    found_agents = sorted(list(set([str(c.agent_hostname) for c in all_changes])))
    if not found_agents and r.agent_list: found_agents = r.agent_list

    for agent in found_agents:
        group_key = agent_to_group.get(clean_host(agent), "UNIQUE")
        if group_key not in groups:
            groups[group_key] = {"id": group_key, "agents": [], "tickets": [], "details": [], "notes": "", "is_locked": False}
        
        groups[group_key]["agents"].append(agent)
        for t in tickets:
            if clean_host(t['agent_hostname']) == clean_host(agent):
                t_obj = dict(t); t_obj['id'] = str(t_obj['id']); t_obj['is_linked'] = bool(t_obj['is_linked'])
                if t_obj not in groups[group_key]["tickets"]: groups[group_key]["tickets"].append(t_obj)
        
        for ac in all_changes:
            if clean_host(ac.agent_hostname) == clean_host(agent):
                groups[group_key]["details"].append({
                    "file_path": ac.file_path, "agent_hostname": ac.agent_hostname,
                    "baseline_hash": ac.baseline_hash, "current_hash": ac.current_hash,
                    "baseline_size": ac.baseline_size, "current_size": ac.current_size,
                    "baseline_mtime": ac.baseline_mtime.isoformat() if ac.baseline_mtime else None,
                    "current_mtime": ac.current_mtime.isoformat() if ac.current_mtime else None,
                    "analyst_notes": ac.analyst_notes
                })
                if ac.analyst_notes:
                    groups[group_key]["notes"] = ac.analyst_notes
                    groups[group_key]["is_locked"] = True

    return {
        "id": r.id, 
        "report_date": r.report_date, 
        "status": r.status, 
        "total_changes": r.total_changes, 
        "rt_ticket_id": getattr(r, 'rt_ticket_id', None),
        "created_at": r.created_at,
        "summary": {
            "added_files": r.total_added or 0, 
            "removed_files": r.total_removed or 0, 
            "changed_files": r.total_changed or 0
        }, 
        "groups": list(groups.values()),
        "agents": found_agents
    }

@router.post("/generate")
async def generate_daily_report(request: GenerateReportRequest, db: AsyncSession = Depends(get_db), u: User = Depends(get_current_user)):
    try:
        report_date = request.report_date or datetime.now().date()
        if request.report_date:
            start_t = datetime.combine(report_date, time.min); end_t = datetime.combine(report_date, time.max)
        else:
            prev_res = await db.execute(select(DailyReport).order_by(DailyReport.created_at.desc()).limit(1))
            pr = prev_res.scalar_one_or_none()
            start_t = pr.created_at if pr else (datetime.utcnow() - timedelta(days=1)); end_t = datetime.utcnow()
        
        res_exists = await db.execute(select(DailyReport).where(DailyReport.report_date == report_date))
        if res_exists.scalar_one_or_none(): raise HTTPException(400, "Exists")

        q = text("SELECT a.id, a.file_path, a.alert_type, a.severity, a.previous_state, a.current_state, a.detected_at, ag.hostname FROM fim.alerts a LEFT JOIN fim.agents ag ON a.agent_id = ag.id WHERE a.created_at >= :s AND a.created_at <= :e")
        res = await db.execute(q, {"s": start_t, "e": end_t})
        all_alerts = res.fetchall()
        seen = set(); alerts = []
        for a in all_alerts:
            if f"{a.hostname}:{a.file_path}" not in seen:
                seen.add(f"{a.hostname}:{a.file_path}"); alerts.append(a)

        report_id = uuid.uuid4(); agent_names = list(set([a.hostname for a in alerts if a.hostname]))
        rt_id = await TicketLinkerService.find_daily_review_ticket(report_date, sso.create_outbound_token(u.username))
        
        # Determine specific counts
        added_n = len([a for a in alerts if 'created' in str(a.alert_type).lower() or 'added' in str(a.alert_type).lower()])
        removed_n = len([a for a in alerts if 'deleted' in str(a.alert_type).lower() or 'removed' in str(a.alert_type).lower()])
        changed_n = len(alerts) - (added_n + removed_n)

        report = DailyReport(
            id=report_id, report_date=report_date, agent_list=agent_names, 
            total_added=added_n, total_removed=removed_n, total_changed=changed_n, 
            total_changes=len(alerts), total_servers=len(agent_names), 
            status='pending', generated_by=u.id, rt_ticket_id=rt_id
        )
        db.add(report); await db.flush()
        for a in alerts:
            try:
                def sj(v): return json.loads(v) if isinstance(v, str) else (v or {})
                p, c = sj(a.previous_state), sj(a.current_state)
                ctype = 'added' if ('created' in str(a.alert_type).lower()) else 'changed'
                db.add(ReportChange(id=uuid.uuid4(), report_id=report_id, alert_id=a.id, agent_hostname=a.hostname or 'unknown', file_path=a.file_path or 'unknown', change_type=ctype, severity=a.severity or 'medium', current_mtime=a.detected_at, baseline_hash=p.get('hash'), current_hash=c.get('hash'), baseline_size=p.get('size'), current_size=c.get('size'), baseline_mtime=datetime.fromisoformat(str(p['mtime']).replace('Z', '+00:00')) if p.get('mtime') else None))
            except: continue
        await TicketLinkerService.correlate_report(report_id, agent_names, u.username, db)
        await db.commit(); return {"message": "Success", "report_id": str(report_id)}
    except Exception as e:
        await db.rollback(); logger.error(f"Generation failed: {e}"); raise HTTPException(500, str(e))

@router.get("/{id_or_date}/export")
async def export_report(id_or_date: str, db: AsyncSession = Depends(get_db)):
    r = await find_report_obj(db, id_or_date)
    if not r: raise HTTPException(404)
    res_c = await db.execute(select(ReportChange).where(ReportChange.report_id == r.id))
    changes = res_c.scalars().all()
    lines = [f"FIM Report: {r.report_date}", "="*20]
    for c in changes:
        lines.append(f"[{c.agent_hostname}] {c.change_type.upper()}: {c.file_path}\n  Hash: {c.baseline_hash} -> {c.current_hash}")
    return Response("\n".join(lines), media_type="text/plain")

@router.delete("/{report_id}")
async def delete_report(report_id: str, db: AsyncSession = Depends(get_db)):
    r = await find_report_obj(db, report_id)
    if not r: raise HTTPException(404)
    await db.execute(text("DELETE FROM fim.report_changes WHERE report_id = :id"), {"id": r.id})
    await db.execute(text("DELETE FROM fim.report_tickets WHERE report_id = :id"), {"id": r.id})
    await db.execute(text("DELETE FROM fim.reports WHERE id = :id"), {"id": r.id})
    await db.commit(); return {"message": "Deleted"}
